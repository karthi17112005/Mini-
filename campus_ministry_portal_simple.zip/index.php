<?php
require_once('db.php');

// Already logged in? Send to the right page.
if (isset($_SESSION['user_id'])) {
    header('Location: ' . ($_SESSION['role'] == 'admin' ? 'dashboard.php' : 'staff.php'));
    exit;
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = trim($_POST['username']);
    $password = $_POST['password'];

    if ($username == '' || $password == '') {
        $error = 'Please enter both username and password.';
    } else {
        $u = esc($username);
        $p = md5($password);
        $result = mysqli_query($conn, "SELECT id, username, full_name, role FROM users WHERE username='$u' AND password='$p' LIMIT 1");

        if ($result && mysqli_num_rows($result) == 1) {
            $user = mysqli_fetch_assoc($result);
            $_SESSION['user_id']   = $user['id'];
            $_SESSION['full_name'] = $user['full_name'];
            $_SESSION['role']      = $user['role'];
            header('Location: ' . ($user['role'] == 'admin' ? 'dashboard.php' : 'staff.php'));
            exit;
        } else {
            $error = 'Invalid username or password.';
        }
    }
}

render_top('Login - Campus Ministry Portal');
?>
<div class="container" style="max-width:380px;margin-top:60px;">
    <div class="card">
        <h2 style="color:#4a2c8f;text-align:center;">Sign In</h2>
        <?php if ($error != ''): ?>
            <div class="alert alert-error"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>
        <form method="post" action="index.php">
            <label>Username</label>
            <input type="text" name="username" required>
            <label>Password</label>
            <input type="password" name="password" required>
            <button type="submit" class="btn" style="width:100%;">Login</button>
        </form>
        <p style="margin-top:14px;font-size:12px;color:#888;text-align:center;">
            Admin: admin / admin123 &nbsp;|&nbsp; Staff: staff / staff123
        </p>
    </div>
</div>
</body></html>
