<?php
require_once('db.php');

if (isset($_SESSION['user_id'])) {
    header('Location: ' . ($_SESSION['role'] == 'admin' ? 'dashboard.php' : 'staff.php'));
    exit;
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (!csrf_check()) {
        $error = 'Your session expired. Please try again.';
    } elseif (login_is_locked()) {
        $error = 'Too many failed attempts. Please wait a minute and try again.';
    } else {
        $username = trim($_POST['username']);
        $password = $_POST['password'];

        if ($username == '' || $password == '') {
            $error = 'Please enter both username and password.';
        } else {
            $stmt = mysqli_prepare($conn, "SELECT id, password, full_name, role FROM users WHERE username = ? LIMIT 1");
            mysqli_stmt_bind_param($stmt, 's', $username);
            mysqli_stmt_execute($stmt);
            $result = mysqli_stmt_get_result($stmt);
            $user = $result ? mysqli_fetch_assoc($result) : null;

            if ($user && verify_password($password, $user['password'])) {
                login_reset_failures();
                session_regenerate_id(true); // prevent session fixation
                $_SESSION['user_id']   = $user['id'];
                $_SESSION['full_name'] = $user['full_name'];
                $_SESSION['role']      = $user['role'];
                header('Location: ' . ($user['role'] == 'admin' ? 'dashboard.php' : 'staff.php'));
                exit;
            } else {
                login_register_failure();
                $error = 'Invalid username or password.';
            }
        }
    }
}

render_top('Login - Campus Ministry Portal');
?>
<div class="container" style="max-width:380px;margin-top:60px;">
    <div class="card">
        <h2 style="color:#4a2c8f;text-align:center;">Sign In</h2>
        <?php if ($error != ''): ?>
            <div class="alert alert-error"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>
        <form method="post" action="index.php">
            <?php csrf_field(); ?>
            <label>Username</label>
            <input type="text" name="username" required autocomplete="username">
            <label>Password</label>
            <input type="password" name="password" required autocomplete="current-password">
            <button type="submit" class="btn" style="width:100%;">Login</button>
        </form>
        <p style="margin-top:14px;font-size:12px;color:#888;text-align:center;">
            Admin: admin / admin123 &nbsp;|&nbsp; Staff: staff / staff123<br>
            (change these passwords after first login)
        </p>
    </div>
</div>
</body></html>
