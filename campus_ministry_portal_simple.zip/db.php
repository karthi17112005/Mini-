<?php
/**
 * db.php
 * Connects to MySQL, auto-creates the database/tables/default logins on
 * first run, and holds shared security + UI helpers used by every page.
 */

// --- Harden session cookies before starting the session ---
ini_set('session.use_only_cookies', 1);
ini_set('session.cookie_httponly', 1);
if (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') {
    ini_set('session.cookie_secure', 1);
}
if (PHP_VERSION_ID >= 50400) {
    session_set_cookie_params(array(
        'lifetime' => 0, 'path' => '/', 'httponly' => true, 'samesite' => 'Lax'
    ));
} else {
    session_set_cookie_params(0, '/');
}
session_start();

$DB_HOST = 'localhost';
$DB_USER = 'root';
$DB_PASS = '';
$DB_NAME = 'campus_ministry_portal';

$conn = mysqli_connect($DB_HOST, $DB_USER, $DB_PASS);
if (!$conn) {
    die('Database connection failed: ' . mysqli_connect_error());
}

mysqli_query($conn, "CREATE DATABASE IF NOT EXISTS $DB_NAME");
mysqli_select_db($conn, $DB_NAME);

mysqli_query($conn, "
    CREATE TABLE IF NOT EXISTS users (
        id INT NOT NULL AUTO_INCREMENT,
        username VARCHAR(50) NOT NULL,
        password VARCHAR(255) NOT NULL,
        full_name VARCHAR(100) NOT NULL,
        role VARCHAR(10) NOT NULL DEFAULT 'staff',
        PRIMARY KEY (id),
        UNIQUE KEY uniq_username (username)
    )
");

mysqli_query($conn, "
    CREATE TABLE IF NOT EXISTS students (
        id INT NOT NULL AUTO_INCREMENT,
        serial_no VARCHAR(20) DEFAULT '',
        d_number VARCHAR(30) NOT NULL,
        name VARCHAR(150) NOT NULL,
        department VARCHAR(100) NOT NULL,
        class VARCHAR(50) NOT NULL,
        section VARCHAR(20) DEFAULT '',
        residency VARCHAR(20) NOT NULL DEFAULT 'Day Scholar',
        religion VARCHAR(50) NOT NULL,
        PRIMARY KEY (id),
        UNIQUE KEY uniq_dnumber (d_number)
    )
");

// ---------------- Password hashing (works on old and new PHP) ----------------
function hash_password($plain) {
    if (function_exists('password_hash')) {
        return password_hash($plain, PASSWORD_DEFAULT);
    }
    return md5($plain); // fallback only for very old PHP without password_hash()
}
function verify_password($plain, $hash) {
    if (function_exists('password_verify') && strlen($hash) > 32) {
        return password_verify($plain, $hash);
    }
    return md5($plain) === $hash; // fallback path matches the fallback hash above
}

// Seed default logins only if the users table is empty
$check = mysqli_query($conn, "SELECT COUNT(*) AS cnt FROM users");
$row = mysqli_fetch_assoc($check);
if ($row['cnt'] == 0) {
    $stmt = mysqli_prepare($conn, "INSERT INTO users (username, password, full_name, role) VALUES (?, ?, ?, ?)");
    $u1 = 'admin'; $p1 = hash_password('admin123'); $n1 = 'System Administrator'; $r1 = 'admin';
    mysqli_stmt_bind_param($stmt, 'ssss', $u1, $p1, $n1, $r1);
    mysqli_stmt_execute($stmt);
    $u2 = 'staff'; $p2 = hash_password('staff123'); $n2 = 'Ministry Staff'; $r2 = 'staff';
    mysqli_stmt_bind_param($stmt, 'ssss', $u2, $p2, $n2, $r2);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);
}

// ---------------- CSRF protection ----------------
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(function_exists('random_bytes') ? random_bytes(32) : openssl_random_pseudo_bytes(32));
}
function csrf_field() {
    echo '<input type="hidden" name="csrf_token" value="' . htmlspecialchars($_SESSION['csrf_token']) . '">';
}
function csrf_token() {
    return $_SESSION['csrf_token'];
}
function csrf_check() {
    $sent = isset($_POST['csrf_token']) ? $_POST['csrf_token'] : (isset($_GET['csrf_token']) ? $_GET['csrf_token'] : '');
    return $sent !== '' && hash_equals($_SESSION['csrf_token'], $sent);
}

// ---------------- Simple login throttling (per-session) ----------------
function login_is_locked() {
    if (!isset($_SESSION['login_fail_count'])) { return false; }
    if ($_SESSION['login_fail_count'] >= 5 && (time() - $_SESSION['login_fail_time']) < 60) {
        return true;
    }
    return false;
}
function login_register_failure() {
    $_SESSION['login_fail_count'] = isset($_SESSION['login_fail_count']) ? $_SESSION['login_fail_count'] + 1 : 1;
    $_SESSION['login_fail_time'] = time();
}
function login_reset_failures() {
    unset($_SESSION['login_fail_count']);
    unset($_SESSION['login_fail_time']);
}

// ---------------- Dropdown option lists (edit these to match your institution) ----------------
$DEPARTMENTS = array('Computer Science', 'Information Technology', 'Data Science', 'Artificial Intelligence',
    'Visual Communication', 'Commerce', 'Business Administration', 'Physics', 'Chemistry', 'Mathematics', 'English', 'Other');

$SECTIONS = array('A', 'B', 'C', 'D');

$RELIGIONS = array('Catholic', 'Protestant', 'Hindu', 'Muslim', 'Sikh', 'Buddhist', 'Jain', 'Other', 'Prefer not to say');

function render_select($name, $options, $selected, $required = true) {
    echo '<select name="' . htmlspecialchars($name) . '"' . ($required ? ' required' : '') . '>';
    if (!$required) { echo '<option value="">All</option>'; }
    foreach ($options as $opt) {
        $sel = ($opt == $selected) ? ' selected' : '';
        echo '<option value="' . htmlspecialchars($opt) . '"' . $sel . '>' . htmlspecialchars($opt) . '</option>';
    }
    echo '</select>';
}

// ---------------- Shared page styling ----------------
function render_top($title) {
    echo "<!DOCTYPE html><html><head><meta charset='UTF-8'><title>" . htmlspecialchars($title) . "</title>";
    echo "<style>
        body{font-family:Arial,Helvetica,sans-serif;background:#f4f6f8;color:#222;margin:0;}
        .topbar{background:#4a2c8f;color:#fff;padding:14px 24px;display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;}
        .topbar a{color:#fff;text-decoration:none;background:rgba(255,255,255,.15);padding:6px 12px;border-radius:4px;}
        .container{max-width:1000px;margin:24px auto;padding:0 16px 40px;}
        .card{background:#fff;padding:20px;border-radius:8px;box-shadow:0 1px 4px rgba(0,0,0,.08);margin-bottom:20px;}
        label{display:block;margin:10px 0 4px;font-weight:bold;font-size:14px;}
        input[type=text],input[type=password],input[type=file],select{width:100%;padding:8px;border:1px solid #ccc;border-radius:4px;font-size:14px;}
        .btn{display:inline-block;background:#4a2c8f;color:#fff;border:none;padding:9px 16px;border-radius:4px;cursor:pointer;font-size:14px;text-decoration:none;margin-top:12px;}
        .btn-secondary{background:#6c757d;} .btn-danger{background:#c0392b;} .btn-small{padding:4px 10px;font-size:12px;margin-top:0;}
        .alert{padding:10px 14px;border-radius:4px;margin-bottom:14px;font-size:14px;}
        .alert-error{background:#fde2e2;color:#a33;border:1px solid #f5b5b5;}
        .alert-success{background:#e2f7e9;color:#227a44;border:1px solid #b6e6c6;}
        table{width:100%;border-collapse:collapse;background:#fff;}
        th,td{padding:7px 9px;border:1px solid #e0e0e0;font-size:13px;text-align:left;}
        th{background:#4a2c8f;color:#fff;}
        .links a{margin-right:14px;font-weight:bold;text-decoration:none;color:#4a2c8f;}
        .filter{display:flex;gap:10px;flex-wrap:wrap;margin-bottom:14px;align-items:end;}
        .filter div{flex:1 1 150px;}
    </style></head><body>";
}

function render_topbar() {
    if (isset($_SESSION['user_id'])) {
        echo "<div class='topbar'><div><strong>Campus Ministry Portal</strong></div>";
        echo "<div>" . htmlspecialchars($_SESSION['full_name']) . " (" . htmlspecialchars($_SESSION['role']) . ") &nbsp; <a href='logout.php'>Logout</a></div></div>";
    }
}
?>
