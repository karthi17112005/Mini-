<?php
/**
 * db.php
 * Connects to MySQL and auto-creates the database, tables, and default
 * logins the first time it runs, so there is no separate .sql file to
 * import. Uses mysqli (available since PHP 5.0), which is the safest
 * choice for "just works" on both old and modern PHP builds.
 */

session_start();

$DB_HOST = 'localhost';
$DB_USER = 'root';
$DB_PASS = '';
$DB_NAME = 'campus_ministry_portal';

// Connect without selecting a database yet, so we can create it if missing
$conn = mysqli_connect($DB_HOST, $DB_USER, $DB_PASS);
if (!$conn) {
    die('Database connection failed: ' . mysqli_connect_error());
}

mysqli_query($conn, "CREATE DATABASE IF NOT EXISTS $DB_NAME");
mysqli_select_db($conn, $DB_NAME);

mysqli_query($conn, "
    CREATE TABLE IF NOT EXISTS users (
        id INT NOT NULL AUTO_INCREMENT,
        username VARCHAR(50) NOT NULL,
        password VARCHAR(64) NOT NULL,
        full_name VARCHAR(100) NOT NULL,
        role VARCHAR(10) NOT NULL DEFAULT 'staff',
        PRIMARY KEY (id),
        UNIQUE KEY uniq_username (username)
    )
");

mysqli_query($conn, "
    CREATE TABLE IF NOT EXISTS students (
        id INT NOT NULL AUTO_INCREMENT,
        serial_no VARCHAR(20) DEFAULT '',
        d_number VARCHAR(30) NOT NULL,
        name VARCHAR(150) NOT NULL,
        department VARCHAR(100) NOT NULL,
        class VARCHAR(50) NOT NULL,
        section VARCHAR(20) DEFAULT '',
        residency VARCHAR(20) NOT NULL DEFAULT 'Day Scholar',
        religion VARCHAR(50) NOT NULL,
        PRIMARY KEY (id),
        UNIQUE KEY uniq_dnumber (d_number)
    )
");

// Seed default logins only if the users table is empty
$check = mysqli_query($conn, "SELECT COUNT(*) AS cnt FROM users");
$row = mysqli_fetch_assoc($check);
if ($row['cnt'] == 0) {
    $admin_pass = md5('admin123');
    $staff_pass = md5('staff123');
    mysqli_query($conn, "INSERT INTO users (username, password, full_name, role) VALUES
        ('admin', '$admin_pass', 'System Administrator', 'admin'),
        ('staff', '$staff_pass', 'Ministry Staff', 'staff')");
}

// Small helper: escape a string for safe use in a query
function esc($value) {
    global $conn;
    return mysqli_real_escape_string($conn, $value);
}

// Shared page styling, used by every page (kept in PHP, no separate CSS file)
function render_top($title) {
    echo "<!DOCTYPE html><html><head><meta charset='UTF-8'><title>" . htmlspecialchars($title) . "</title>";
    echo "<style>
        body{font-family:Arial,Helvetica,sans-serif;background:#f4f6f8;color:#222;margin:0;}
        .topbar{background:#4a2c8f;color:#fff;padding:14px 24px;display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;}
        .topbar a{color:#fff;text-decoration:none;background:rgba(255,255,255,.15);padding:6px 12px;border-radius:4px;}
        .container{max-width:1000px;margin:24px auto;padding:0 16px 40px;}
        .card{background:#fff;padding:20px;border-radius:8px;box-shadow:0 1px 4px rgba(0,0,0,.08);margin-bottom:20px;}
        label{display:block;margin:10px 0 4px;font-weight:bold;font-size:14px;}
        input[type=text],input[type=password],input[type=file],select{width:100%;padding:8px;border:1px solid #ccc;border-radius:4px;font-size:14px;}
        .btn{display:inline-block;background:#4a2c8f;color:#fff;border:none;padding:9px 16px;border-radius:4px;cursor:pointer;font-size:14px;text-decoration:none;margin-top:12px;}
        .btn-secondary{background:#6c757d;} .btn-danger{background:#c0392b;} .btn-small{padding:4px 10px;font-size:12px;margin-top:0;}
        .alert{padding:10px 14px;border-radius:4px;margin-bottom:14px;font-size:14px;}
        .alert-error{background:#fde2e2;color:#a33;border:1px solid #f5b5b5;}
        .alert-success{background:#e2f7e9;color:#227a44;border:1px solid #b6e6c6;}
        table{width:100%;border-collapse:collapse;background:#fff;}
        th,td{padding:7px 9px;border:1px solid #e0e0e0;font-size:13px;text-align:left;}
        th{background:#4a2c8f;color:#fff;}
        .links a{margin-right:14px;font-weight:bold;text-decoration:none;color:#4a2c8f;}
        .filter{display:flex;gap:10px;flex-wrap:wrap;margin-bottom:14px;align-items:end;}
        .filter div{flex:1 1 150px;}
    </style></head><body>";
}

function render_topbar() {
    if (isset($_SESSION['user_id'])) {
        echo "<div class='topbar'><div><strong>Campus Ministry Portal</strong></div>";
        echo "<div>" . htmlspecialchars($_SESSION['full_name']) . " (" . htmlspecialchars($_SESSION['role']) . ") &nbsp; <a href='logout.php'>Logout</a></div></div>";
    }
}
?>
