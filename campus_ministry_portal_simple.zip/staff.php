<?php
require_once('db.php');

if (!isset($_SESSION['user_id'])) {
    header('Location: index.php');
    exit;
}

$search = isset($_GET['q']) ? trim($_GET['q']) : '';
$dept   = isset($_GET['department']) ? trim($_GET['department']) : '';
$class  = isset($_GET['class']) ? trim($_GET['class']) : '';
$hasSearched = ($search != '' || $dept != '' || $class != '');

$results = array();
if ($hasSearched) {
    $where = array();
    $types = '';
    $params = array();

    if ($search != '') {
        $where[] = "(name LIKE ? OR d_number LIKE ? OR serial_no LIKE ?)";
        $like = '%' . $search . '%';
        $types .= 'sss'; $params[] = $like; $params[] = $like; $params[] = $like;
    }
    if ($dept != '')  { $where[] = "department = ?"; $types .= 's'; $params[] = $dept; }
    if ($class != '') { $where[] = "class = ?"; $types .= 's'; $params[] = $class; }

    $whereSql = count($where) > 0 ? ('WHERE ' . implode(' AND ', $where)) : '';
    $stmt = mysqli_prepare($conn, "SELECT * FROM students $whereSql ORDER BY name ASC LIMIT 500");
    if (count($params) > 0) {
        $refs = array();
        $refs[] = &$types;
        for ($i = 0; $i < count($params); $i++) { $refs[] = &$params[$i]; }
        call_user_func_array('mysqli_stmt_bind_param', array_merge(array($stmt), $refs));
    }
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    if ($result) { while ($row = mysqli_fetch_assoc($result)) { $results[] = $row; } }
}

render_top('Student Search - Campus Ministry Portal');
render_topbar();
?>
<div class="container">
    <div class="card">
        <h2>Student Search &amp; View (Read-Only)</h2>
        <?php if ($_SESSION['role'] == 'admin'): ?>
            <p class="links"><a href="dashboard.php">Back to Admin Dashboard</a></p>
        <?php endif; ?>

        <form method="get" action="staff.php">
            <div class="filter">
                <div><label>Search</label><input type="text" name="q" value="<?php echo htmlspecialchars($search); ?>" placeholder="Name / D-Number / Serial No."></div>
                <div><label>Department</label><?php render_select('department', $DEPARTMENTS, $dept, false); ?></div>
                <div><label>Class</label><input type="text" name="class" value="<?php echo htmlspecialchars($class); ?>"></div>
                <div><button type="submit" class="btn btn-small">Search</button> <a href="staff.php" class="btn btn-small btn-secondary">Reset</a></div>
            </div>
        </form>

        <?php if ($hasSearched): ?>
            <table>
                <tr><th>S.No</th><th>D-Number</th><th>Name</th><th>Department</th><th>Class</th><th>Section</th><th>Residency</th><th>Religion</th></tr>
                <?php if (count($results) == 0): ?>
                    <tr><td colspan="8" style="text-align:center;">No matching student records found.</td></tr>
                <?php else: foreach ($results as $row): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($row['serial_no']); ?></td>
                        <td><?php echo htmlspecialchars($row['d_number']); ?></td>
                        <td><?php echo htmlspecialchars($row['name']); ?></td>
                        <td><?php echo htmlspecialchars($row['department']); ?></td>
                        <td><?php echo htmlspecialchars($row['class']); ?></td>
                        <td><?php echo htmlspecialchars($row['section']); ?></td>
                        <td><?php echo htmlspecialchars($row['residency']); ?></td>
                        <td><?php echo htmlspecialchars($row['religion']); ?></td>
                    </tr>
                <?php endforeach; endif; ?>
            </table>
        <?php else: ?>
            <p style="color:#888;">Enter a search term or choose a department/class to view records.</p>
        <?php endif; ?>
    </div>
</div>
</body></html>
