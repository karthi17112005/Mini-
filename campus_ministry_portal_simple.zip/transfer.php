<?php
require_once('db.php');

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header('Location: index.php');
    exit;
}

$message = '';
$messageType = '';
$skipped = array();

// ---------- IMPORT ----------
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_FILES['csv_file'])) {
    if (!csrf_check()) {
        $message = 'Your session expired. Please try again.';
        $messageType = 'error';
    } elseif ($_FILES['csv_file']['error'] !== UPLOAD_ERR_OK) {
        $message = 'File upload failed. Please try again.';
        $messageType = 'error';
    } else {
        $handle = fopen($_FILES['csv_file']['tmp_name'], 'r');
        if (!$handle) {
            $message = 'Could not read the uploaded file.';
            $messageType = 'error';
        } else {
            $insert_stmt = mysqli_prepare($conn, "INSERT INTO students (serial_no, d_number, name, department, class, section, residency, religion) VALUES (?,?,?,?,?,?,?,?)");
            $check_stmt  = mysqli_prepare($conn, "SELECT id FROM students WHERE d_number=? LIMIT 1");

            $rowNum = 0;
            $imported = 0;
            while (($row = fgetcsv($handle, 2000, ',')) !== false) {
                $rowNum++;
                if ($rowNum == 1) { continue; } // header row
                if (count($row) < 8) { $skipped[] = "Row $rowNum: not enough columns"; continue; }

                list($serial_no, $d_number, $name, $department, $class, $section, $residency, $religion) = array_map('trim', $row);

                if ($d_number == '' || $name == '' || $department == '' || $class == '' || $religion == '') {
                    $skipped[] = "Row $rowNum: missing required field(s)"; continue;
                }
                if (!in_array($department, $DEPARTMENTS)) { $skipped[] = "Row $rowNum: unrecognized department '$department'"; continue; }
                if ($section != '' && !in_array($section, $SECTIONS)) { $skipped[] = "Row $rowNum: unrecognized section '$section'"; continue; }
                if (!in_array($religion, $RELIGIONS)) { $skipped[] = "Row $rowNum: unrecognized religion '$religion'"; continue; }
                if ($residency != 'Day Scholar' && $residency != 'Hosteller') { $residency = 'Day Scholar'; }

                mysqli_stmt_bind_param($check_stmt, 's', $d_number);
                mysqli_stmt_execute($check_stmt);
                mysqli_stmt_store_result($check_stmt);
                if (mysqli_stmt_num_rows($check_stmt) > 0) {
                    $skipped[] = "Row $rowNum: D-Number '$d_number' already exists"; continue;
                }

                mysqli_stmt_bind_param($insert_stmt, 'ssssssss', $serial_no, $d_number, $name, $department, $class, $section, $residency, $religion);
                if (mysqli_stmt_execute($insert_stmt)) { $imported++; }
                else { $skipped[] = "Row $rowNum: database error"; }
            }
            fclose($handle);
            $message = "$imported student record(s) imported successfully.";
            $messageType = 'success';
        }
    }
}

// ---------- EXPORT (streams a CSV file and exits) ----------
if (isset($_GET['export']) && $_GET['export'] == '1') {
    if (!csrf_check()) {
        die('Your session expired. Please go back and try again.');
    }
    $dept = isset($_GET['department']) ? trim($_GET['department']) : '';
    $class = isset($_GET['class']) ? trim($_GET['class']) : '';
    $religion = isset($_GET['religion']) ? trim($_GET['religion']) : '';
    $residency = isset($_GET['residency']) ? trim($_GET['residency']) : '';

    $where = array();
    $types = '';
    $params = array();
    if ($dept != '')      { $where[] = "department = ?"; $types .= 's'; $params[] = $dept; }
    if ($class != '')     { $where[] = "class = ?"; $types .= 's'; $params[] = $class; }
    if ($religion != '')  { $where[] = "religion = ?"; $types .= 's'; $params[] = $religion; }
    if ($residency != '') { $where[] = "residency = ?"; $types .= 's'; $params[] = $residency; }
    $whereSql = count($where) > 0 ? ('WHERE ' . implode(' AND ', $where)) : '';

    $stmt = mysqli_prepare($conn, "SELECT serial_no, d_number, name, department, class, section, residency, religion FROM students $whereSql ORDER BY department, class, name");
    if (count($params) > 0) {
        $refs = array();
        $refs[] = &$types;
        for ($i = 0; $i < count($params); $i++) { $refs[] = &$params[$i]; }
        call_user_func_array('mysqli_stmt_bind_param', array_merge(array($stmt), $refs));
    }
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);

    header('Content-Type: text/csv; charset=UTF-8');
    header('Content-Disposition: attachment; filename="student_export_' . date('Ymd_His') . '.csv"');
    $out = fopen('php://output', 'w');
    fputcsv($out, array('Serial No','D-Number','Name','Department','Class','Section','Residency','Religion'));
    while ($row = mysqli_fetch_assoc($result)) { fputcsv($out, $row); }
    fclose($out);
    exit;
}

render_top('Bulk Import / Export - Campus Ministry Portal');
render_topbar();
?>
<div class="container">
    <p class="links" style="margin-bottom:16px;"><a href="dashboard.php">&laquo; Back to Dashboard</a></p>

    <?php if ($message != ''): ?><div class="alert alert-<?php echo $messageType; ?>"><?php echo htmlspecialchars($message); ?></div><?php endif; ?>
    <?php if (count($skipped) > 0): ?>
        <div class="alert alert-error">
            <strong><?php echo count($skipped); ?> row(s) skipped:</strong>
            <ul style="margin:6px 0 0 18px;"><?php foreach ($skipped as $s) { echo '<li>' . htmlspecialchars($s) . '</li>'; } ?></ul>
        </div>
    <?php endif; ?>

    <div class="card">
        <h2>Bulk Import (CSV)</h2>
        <p>Column order: <code>serial_no, d_number, name, department, class, section, residency, religion</code> (header row skipped automatically).</p>
        <p style="font-size:12px;color:#888;">
            Department must exactly match one of: <?php echo htmlspecialchars(implode(', ', $DEPARTMENTS)); ?>.<br>
            Section must be one of: <?php echo htmlspecialchars(implode(', ', $SECTIONS)); ?> (or blank).<br>
            Religion must exactly match one of: <?php echo htmlspecialchars(implode(', ', $RELIGIONS)); ?>.<br>
            Residency must be "Day Scholar" or "Hosteller". If you have an .xlsx file, open it in Excel and choose "Save As &rarr; CSV" first.
        </p>
        <form method="post" action="transfer.php" enctype="multipart/form-data">
            <?php csrf_field(); ?>
            <label>CSV File *</label>
            <input type="file" name="csv_file" accept=".csv" required>
            <button type="submit" class="btn">Upload &amp; Import</button>
        </form>
    </div>

    <div class="card">
        <h2>Filter &amp; Export</h2>
        <form method="get" action="transfer.php">
            <input type="hidden" name="export" value="1">
            <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars(csrf_token()); ?>">
            <label>Department</label>
            <?php render_select('department', $DEPARTMENTS, '', false); ?>
            <label>Class</label>
            <input type="text" name="class" placeholder="Leave blank for all">
            <label>Religion</label>
            <?php render_select('religion', $RELIGIONS, '', false); ?>
            <label>Residency</label>
            <select name="residency">
                <option value="">All</option>
                <option value="Day Scholar">Day Scholar</option>
                <option value="Hosteller">Hosteller</option>
            </select>
            <button type="submit" class="btn">Export to CSV (Excel)</button>
        </form>
    </div>
</div>
</body></html>
