<?php
require_once('db.php');

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header('Location: index.php');
    exit;
}

$message = '';
$messageType = '';
$skipped = array();

// ---------- IMPORT ----------
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_FILES['csv_file'])) {
    if ($_FILES['csv_file']['error'] !== UPLOAD_ERR_OK) {
        $message = 'File upload failed. Please try again.';
        $messageType = 'error';
    } else {
        $handle = fopen($_FILES['csv_file']['tmp_name'], 'r');
        if (!$handle) {
            $message = 'Could not read the uploaded file.';
            $messageType = 'error';
        } else {
            $rowNum = 0;
            $imported = 0;
            while (($row = fgetcsv($handle, 2000, ',')) !== false) {
                $rowNum++;
                if ($rowNum == 1) { continue; } // header row
                if (count($row) < 8) { $skipped[] = "Row $rowNum: not enough columns"; continue; }

                list($serial_no, $d_number, $name, $department, $class, $section, $residency, $religion) = array_map('trim', $row);

                if ($d_number == '' || $name == '' || $department == '' || $class == '' || $religion == '') {
                    $skipped[] = "Row $rowNum: missing required field(s)"; continue;
                }
                if ($residency != 'Day Scholar' && $residency != 'Hosteller') { $residency = 'Day Scholar'; }

                $dnum_esc = esc($d_number);
                $existing = mysqli_query($conn, "SELECT id FROM students WHERE d_number='$dnum_esc' LIMIT 1");
                if ($existing && mysqli_num_rows($existing) > 0) {
                    $skipped[] = "Row $rowNum: D-Number '$d_number' already exists"; continue;
                }

                $sql = "INSERT INTO students (serial_no, d_number, name, department, class, section, residency, religion) VALUES (
                    '" . esc($serial_no) . "','" . esc($d_number) . "','" . esc($name) . "','" . esc($department) .
                    "','" . esc($class) . "','" . esc($section) . "','" . esc($residency) . "','" . esc($religion) . "')";
                if (mysqli_query($conn, $sql)) { $imported++; }
                else { $skipped[] = "Row $rowNum: database error"; }
            }
            fclose($handle);
            $message = "$imported student record(s) imported successfully.";
            $messageType = 'success';
        }
    }
}

// ---------- EXPORT (streams a CSV file and exits) ----------
if (isset($_GET['export']) && $_GET['export'] == '1') {
    $dept = isset($_GET['department']) ? trim($_GET['department']) : '';
    $class = isset($_GET['class']) ? trim($_GET['class']) : '';
    $religion = isset($_GET['religion']) ? trim($_GET['religion']) : '';
    $residency = isset($_GET['residency']) ? trim($_GET['residency']) : '';

    $where = array();
    if ($dept != '')      { $where[] = "department='" . esc($dept) . "'"; }
    if ($class != '')     { $where[] = "class='" . esc($class) . "'"; }
    if ($religion != '')  { $where[] = "religion='" . esc($religion) . "'"; }
    if ($residency != '') { $where[] = "residency='" . esc($residency) . "'"; }
    $whereSql = count($where) > 0 ? ('WHERE ' . implode(' AND ', $where)) : '';

    $result = mysqli_query($conn, "SELECT serial_no, d_number, name, department, class, section, residency, religion FROM students $whereSql ORDER BY department, class, name");

    header('Content-Type: text/csv; charset=UTF-8');
    header('Content-Disposition: attachment; filename="student_export_' . date('Ymd_His') . '.csv"');
    $out = fopen('php://output', 'w');
    fputcsv($out, array('Serial No','D-Number','Name','Department','Class','Section','Residency','Religion'));
    while ($row = mysqli_fetch_assoc($result)) { fputcsv($out, $row); }
    fclose($out);
    exit;
}

render_top('Bulk Import / Export - Campus Ministry Portal');
render_topbar();
?>
<div class="container">
    <p class="links" style="margin-bottom:16px;"><a href="dashboard.php">&laquo; Back to Dashboard</a></p>

    <?php if ($message != ''): ?><div class="alert alert-<?php echo $messageType; ?>"><?php echo htmlspecialchars($message); ?></div><?php endif; ?>
    <?php if (count($skipped) > 0): ?>
        <div class="alert alert-error">
            <strong><?php echo count($skipped); ?> row(s) skipped:</strong>
            <ul style="margin:6px 0 0 18px;"><?php foreach ($skipped as $s) { echo '<li>' . htmlspecialchars($s) . '</li>'; } ?></ul>
        </div>
    <?php endif; ?>

    <div class="card">
        <h2>Bulk Import (CSV)</h2>
        <p>Column order: <code>serial_no, d_number, name, department, class, section, residency, religion</code> (header row skipped automatically). Residency must be "Day Scholar" or "Hosteller".</p>
        <p style="font-size:12px;color:#888;">If you have an .xlsx file, open it in Excel and choose "Save As &rarr; CSV" first.</p>
        <form method="post" action="transfer.php" enctype="multipart/form-data">
            <label>CSV File *</label>
            <input type="file" name="csv_file" accept=".csv" required>
            <button type="submit" class="btn">Upload &amp; Import</button>
        </form>
    </div>

    <div class="card">
        <h2>Filter &amp; Export</h2>
        <form method="get" action="transfer.php">
            <input type="hidden" name="export" value="1">
            <label>Department</label>
            <input type="text" name="department" placeholder="Leave blank for all">
            <label>Class</label>
            <input type="text" name="class" placeholder="Leave blank for all">
            <label>Religion</label>
            <input type="text" name="religion" placeholder="Leave blank for all">
            <label>Residency</label>
            <select name="residency">
                <option value="">All</option>
                <option value="Day Scholar">Day Scholar</option>
                <option value="Hosteller">Hosteller</option>
            </select>
            <button type="submit" class="btn">Export to CSV (Excel)</button>
        </form>
    </div>
</div>
</body></html>
