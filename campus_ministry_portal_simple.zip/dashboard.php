<?php
require_once('db.php');

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header('Location: index.php');
    exit;
}

$action  = isset($_GET['action']) ? $_GET['action'] : 'list';
$message = '';
$error   = '';

// ---------- SAVE (create or update) ----------
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['do_save'])) {
    $id         = isset($_POST['id']) ? (int)$_POST['id'] : 0;
    $serial_no  = trim($_POST['serial_no']);
    $d_number   = trim($_POST['d_number']);
    $name       = trim($_POST['name']);
    $department = trim($_POST['department']);
    $class      = trim($_POST['class']);
    $section    = trim($_POST['section']);
    $residency  = trim($_POST['residency']);
    $religion   = trim($_POST['religion']);

    if ($d_number == '' || $name == '' || $department == '' || $class == '' || $religion == '') {
        $error = 'Please fill in all required fields (D-Number, Name, Department, Class, Religion).';
        $action = ($id > 0) ? 'edit' : 'add';
    } else {
        $dnum_esc = esc($d_number);
        $dupe_sql = ($id > 0)
            ? "SELECT id FROM students WHERE d_number='$dnum_esc' AND id<>$id LIMIT 1"
            : "SELECT id FROM students WHERE d_number='$dnum_esc' LIMIT 1";
        $dupe = mysqli_query($conn, $dupe_sql);

        if ($dupe && mysqli_num_rows($dupe) > 0) {
            $error = 'Another student already uses this D-Number.';
            $action = ($id > 0) ? 'edit' : 'add';
        } else {
            $fields = "serial_no='" . esc($serial_no) . "', d_number='" . esc($d_number) . "', name='" . esc($name) .
                "', department='" . esc($department) . "', class='" . esc($class) . "', section='" . esc($section) .
                "', residency='" . esc($residency) . "', religion='" . esc($religion) . "'";

            if ($id > 0) {
                mysqli_query($conn, "UPDATE students SET $fields WHERE id=$id");
                $message = 'Student record updated.';
            } else {
                mysqli_query($conn, "INSERT INTO students SET $fields");
                $message = 'Student record added.';
            }
            $action = 'list';
        }
    }
}

// ---------- DELETE (with a plain-link confirm step, no JS) ----------
if ($action == 'delete') {
    $id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
    if (isset($_GET['confirm']) && $_GET['confirm'] == '1') {
        mysqli_query($conn, "DELETE FROM students WHERE id=$id");
        $message = 'Student record deleted.';
        $action = 'list';
    }
}

render_top('Admin Dashboard - Campus Ministry Portal');
render_topbar();
?>
<div class="container">

<?php if ($message != ''): ?><div class="alert alert-success"><?php echo htmlspecialchars($message); ?></div><?php endif; ?>
<?php if ($error != ''): ?><div class="alert alert-error"><?php echo htmlspecialchars($error); ?></div><?php endif; ?>

<?php if ($action == 'delete' && !isset($_GET['confirm'])):
    $id = (int)$_GET['id'];
    $r = mysqli_query($conn, "SELECT name FROM students WHERE id=$id LIMIT 1");
    $s = mysqli_fetch_assoc($r);
?>
    <div class="card">
        <p>Delete student record for <strong><?php echo htmlspecialchars($s['name']); ?></strong>? This cannot be undone.</p>
        <a class="btn btn-danger" href="dashboard.php?action=delete&id=<?php echo $id; ?>&confirm=1">Yes, delete</a>
        <a class="btn btn-secondary" href="dashboard.php">Cancel</a>
    </div>

<?php elseif ($action == 'add' || $action == 'edit'):
    $vals = array('id'=>0,'serial_no'=>'','d_number'=>'','name'=>'','department'=>'','class'=>'','section'=>'','residency'=>'Day Scholar','religion'=>'');
    if ($action == 'edit') {
        $id = isset($_GET['id']) ? (int)$_GET['id'] : (isset($_POST['id']) ? (int)$_POST['id'] : 0);
        $r = mysqli_query($conn, "SELECT * FROM students WHERE id=$id LIMIT 1");
        if ($r && mysqli_num_rows($r) == 1) { $vals = mysqli_fetch_assoc($r); }
    }
    if (isset($_POST['do_save']) && $error != '') {
        foreach ($vals as $k => $v) { if (isset($_POST[$k])) { $vals[$k] = $_POST[$k]; } }
    }
?>
    <div class="card" style="max-width:600px;">
        <h2><?php echo $action == 'edit' ? 'Edit Student' : 'Add New Student'; ?></h2>
        <form method="post" action="dashboard.php">
            <input type="hidden" name="id" value="<?php echo (int)$vals['id']; ?>">
            <label>Serial No.</label>
            <input type="text" name="serial_no" value="<?php echo htmlspecialchars($vals['serial_no']); ?>">
            <label>D-Number *</label>
            <input type="text" name="d_number" value="<?php echo htmlspecialchars($vals['d_number']); ?>" required>
            <label>Full Name *</label>
            <input type="text" name="name" value="<?php echo htmlspecialchars($vals['name']); ?>" required>
            <label>Department *</label>
            <input type="text" name="department" value="<?php echo htmlspecialchars($vals['department']); ?>" required>
            <label>Class *</label>
            <input type="text" name="class" value="<?php echo htmlspecialchars($vals['class']); ?>" required>
            <label>Section</label>
            <input type="text" name="section" value="<?php echo htmlspecialchars($vals['section']); ?>">
            <label>Residency *</label>
            <select name="residency">
                <option value="Day Scholar" <?php echo ($vals['residency']=='Day Scholar')?'selected':''; ?>>Day Scholar</option>
                <option value="Hosteller" <?php echo ($vals['residency']=='Hosteller')?'selected':''; ?>>Hosteller</option>
            </select>
            <label>Religious Affiliation *</label>
            <input type="text" name="religion" value="<?php echo htmlspecialchars($vals['religion']); ?>" required>
            <button type="submit" name="do_save" value="1" class="btn">Save</button>
            <a href="dashboard.php" class="btn btn-secondary">Cancel</a>
        </form>
    </div>

<?php else: // ---------- LIST + SEARCH/FILTER ----------
    $search = isset($_GET['q']) ? trim($_GET['q']) : '';
    $dept   = isset($_GET['department']) ? trim($_GET['department']) : '';
    $class  = isset($_GET['class']) ? trim($_GET['class']) : '';
    $religion = isset($_GET['religion']) ? trim($_GET['religion']) : '';

    $where = array();
    if ($search != '') { $s = esc($search); $where[] = "(name LIKE '%$s%' OR d_number LIKE '%$s%' OR serial_no LIKE '%$s%')"; }
    if ($dept != '')     { $where[] = "department='" . esc($dept) . "'"; }
    if ($class != '')    { $where[] = "class='" . esc($class) . "'"; }
    if ($religion != '') { $where[] = "religion='" . esc($religion) . "'"; }
    $whereSql = count($where) > 0 ? ('WHERE ' . implode(' AND ', $where)) : '';

    $result = mysqli_query($conn, "SELECT * FROM students $whereSql ORDER BY name ASC");
?>
    <div class="card">
        <div class="links">
            <a href="dashboard.php?action=add">+ Add Student</a>
            <a href="transfer.php">Bulk Import / Export</a>
            <a href="staff.php">Staff Search View</a>
        </div>
    </div>

    <div class="card">
        <h2>Students</h2>
        <form method="get" action="dashboard.php">
            <div class="filter">
                <div><label>Search</label><input type="text" name="q" value="<?php echo htmlspecialchars($search); ?>" placeholder="Name / D-Number / Serial No."></div>
                <div><label>Department</label><input type="text" name="department" value="<?php echo htmlspecialchars($dept); ?>"></div>
                <div><label>Class</label><input type="text" name="class" value="<?php echo htmlspecialchars($class); ?>"></div>
                <div><label>Religion</label><input type="text" name="religion" value="<?php echo htmlspecialchars($religion); ?>"></div>
                <div><button type="submit" class="btn btn-small">Filter</button> <a href="dashboard.php" class="btn btn-small btn-secondary">Reset</a></div>
            </div>
        </form>

        <table>
            <tr><th>S.No</th><th>D-Number</th><th>Name</th><th>Department</th><th>Class</th><th>Section</th><th>Residency</th><th>Religion</th><th>Actions</th></tr>
            <?php if (!$result || mysqli_num_rows($result) == 0): ?>
                <tr><td colspan="9" style="text-align:center;">No student records found.</td></tr>
            <?php else: while ($row = mysqli_fetch_assoc($result)): ?>
                <tr>
                    <td><?php echo htmlspecialchars($row['serial_no']); ?></td>
                    <td><?php echo htmlspecialchars($row['d_number']); ?></td>
                    <td><?php echo htmlspecialchars($row['name']); ?></td>
                    <td><?php echo htmlspecialchars($row['department']); ?></td>
                    <td><?php echo htmlspecialchars($row['class']); ?></td>
                    <td><?php echo htmlspecialchars($row['section']); ?></td>
                    <td><?php echo htmlspecialchars($row['residency']); ?></td>
                    <td><?php echo htmlspecialchars($row['religion']); ?></td>
                    <td>
                        <a href="dashboard.php?action=edit&id=<?php echo $row['id']; ?>">Edit</a> |
                        <a href="dashboard.php?action=delete&id=<?php echo $row['id']; ?>">Delete</a>
                    </td>
                </tr>
            <?php endwhile; endif; ?>
        </table>
    </div>
<?php endif; ?>

</div>
</body></html>
