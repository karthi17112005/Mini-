<?php
require_once('db.php');

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header('Location: index.php');
    exit;
}

$action  = isset($_GET['action']) ? $_GET['action'] : 'list';
$message = '';
$error   = '';

// ---------- SAVE (create or update) ----------
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['do_save'])) {
    if (!csrf_check()) {
        $error = 'Your session expired. Please try again.';
        $action = isset($_POST['id']) && (int)$_POST['id'] > 0 ? 'edit' : 'add';
    } else {
        $id         = isset($_POST['id']) ? (int)$_POST['id'] : 0;
        $serial_no  = trim($_POST['serial_no']);
        $d_number   = trim($_POST['d_number']);
        $name       = trim($_POST['name']);
        $department = trim($_POST['department']);
        $class      = trim($_POST['class']);
        $section    = trim($_POST['section']);
        $residency  = trim($_POST['residency']);
        $religion   = trim($_POST['religion']);

        // Validate dropdown values against the allowed lists (defense against tampered requests)
        if (!in_array($department, $DEPARTMENTS)) { $department = ''; }
        if ($section != '' && !in_array($section, $SECTIONS)) { $section = ''; }
        if (!in_array($religion, $RELIGIONS)) { $religion = ''; }
        if ($residency != 'Day Scholar' && $residency != 'Hosteller') { $residency = 'Day Scholar'; }

        if ($d_number == '' || $name == '' || $department == '' || $class == '' || $religion == '') {
            $error = 'Please fill in all required fields with valid values.';
            $action = ($id > 0) ? 'edit' : 'add';
        } else {
            $dupe_stmt = ($id > 0)
                ? mysqli_prepare($conn, "SELECT id FROM students WHERE d_number=? AND id<>? LIMIT 1")
                : mysqli_prepare($conn, "SELECT id FROM students WHERE d_number=? LIMIT 1");
            if ($id > 0) { mysqli_stmt_bind_param($dupe_stmt, 'si', $d_number, $id); }
            else { mysqli_stmt_bind_param($dupe_stmt, 's', $d_number); }
            mysqli_stmt_execute($dupe_stmt);
            mysqli_stmt_store_result($dupe_stmt);

            if (mysqli_stmt_num_rows($dupe_stmt) > 0) {
                $error = 'Another student already uses this D-Number.';
                $action = ($id > 0) ? 'edit' : 'add';
            } else {
                if ($id > 0) {
                    $stmt = mysqli_prepare($conn, "UPDATE students SET serial_no=?, d_number=?, name=?, department=?, class=?, section=?, residency=?, religion=? WHERE id=?");
                    mysqli_stmt_bind_param($stmt, 'ssssssssi', $serial_no, $d_number, $name, $department, $class, $section, $residency, $religion, $id);
                    mysqli_stmt_execute($stmt);
                    $message = 'Student record updated.';
                } else {
                    $stmt = mysqli_prepare($conn, "INSERT INTO students (serial_no, d_number, name, department, class, section, residency, religion) VALUES (?,?,?,?,?,?,?,?)");
                    mysqli_stmt_bind_param($stmt, 'ssssssss', $serial_no, $d_number, $name, $department, $class, $section, $residency, $religion);
                    mysqli_stmt_execute($stmt);
                    $message = 'Student record added.';
                }
                $action = 'list';
            }
        }
    }
}

// ---------- DELETE (plain-link confirm step + CSRF, no JS) ----------
if ($action == 'delete') {
    $id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
    if (isset($_GET['confirm']) && $_GET['confirm'] == '1') {
        if (!csrf_check()) {
            $error = 'Your session expired. Please try again.';
            $action = 'list';
        } else {
            $stmt = mysqli_prepare($conn, "DELETE FROM students WHERE id=?");
            mysqli_stmt_bind_param($stmt, 'i', $id);
            mysqli_stmt_execute($stmt);
            $message = 'Student record deleted.';
            $action = 'list';
        }
    }
}

render_top('Admin Dashboard - Campus Ministry Portal');
render_topbar();
?>
<div class="container">

<?php if ($message != ''): ?><div class="alert alert-success"><?php echo htmlspecialchars($message); ?></div><?php endif; ?>
<?php if ($error != ''): ?><div class="alert alert-error"><?php echo htmlspecialchars($error); ?></div><?php endif; ?>

<?php if ($action == 'delete' && !isset($_GET['confirm'])):
    $id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
    $stmt = mysqli_prepare($conn, "SELECT name FROM students WHERE id=? LIMIT 1");
    mysqli_stmt_bind_param($stmt, 'i', $id);
    mysqli_stmt_execute($stmt);
    $r = mysqli_stmt_get_result($stmt);
    $s = $r ? mysqli_fetch_assoc($r) : null;
?>
    <div class="card">
        <p>Delete student record for <strong><?php echo htmlspecialchars($s ? $s['name'] : ''); ?></strong>? This cannot be undone.</p>
        <a class="btn btn-danger" href="dashboard.php?action=delete&id=<?php echo $id; ?>&confirm=1&csrf_token=<?php echo urlencode(csrf_token()); ?>">Yes, delete</a>
        <a class="btn btn-secondary" href="dashboard.php">Cancel</a>
    </div>

<?php elseif ($action == 'add' || $action == 'edit'):
    $vals = array('id'=>0,'serial_no'=>'','d_number'=>'','name'=>'','department'=>'','class'=>'','section'=>'','residency'=>'Day Scholar','religion'=>'');
    if ($action == 'edit') {
        $id = isset($_GET['id']) ? (int)$_GET['id'] : (isset($_POST['id']) ? (int)$_POST['id'] : 0);
        $stmt = mysqli_prepare($conn, "SELECT * FROM students WHERE id=? LIMIT 1");
        mysqli_stmt_bind_param($stmt, 'i', $id);
        mysqli_stmt_execute($stmt);
        $r = mysqli_stmt_get_result($stmt);
        if ($r && mysqli_num_rows($r) == 1) { $vals = mysqli_fetch_assoc($r); }
    }
    if (isset($_POST['do_save']) && $error != '') {
        foreach ($vals as $k => $v) { if (isset($_POST[$k])) { $vals[$k] = $_POST[$k]; } }
    }
?>
    <div class="card" style="max-width:600px;">
        <h2><?php echo $action == 'edit' ? 'Edit Student' : 'Add New Student'; ?></h2>
        <form method="post" action="dashboard.php">
            <?php csrf_field(); ?>
            <input type="hidden" name="id" value="<?php echo (int)$vals['id']; ?>">
            <label>Serial No.</label>
            <input type="text" name="serial_no" value="<?php echo htmlspecialchars($vals['serial_no']); ?>">
            <label>D-Number *</label>
            <input type="text" name="d_number" value="<?php echo htmlspecialchars($vals['d_number']); ?>" required>
            <label>Full Name *</label>
            <input type="text" name="name" value="<?php echo htmlspecialchars($vals['name']); ?>" required>
            <label>Department *</label>
            <?php render_select('department', $DEPARTMENTS, $vals['department']); ?>
            <label>Class *</label>
            <input type="text" name="class" value="<?php echo htmlspecialchars($vals['class']); ?>" required>
            <label>Section</label>
            <?php render_select('section', $SECTIONS, $vals['section'], false); ?>
            <label>Residency *</label>
            <select name="residency">
                <option value="Day Scholar" <?php echo ($vals['residency']=='Day Scholar')?'selected':''; ?>>Day Scholar</option>
                <option value="Hosteller" <?php echo ($vals['residency']=='Hosteller')?'selected':''; ?>>Hosteller</option>
            </select>
            <label>Religious Affiliation *</label>
            <?php render_select('religion', $RELIGIONS, $vals['religion']); ?>
            <button type="submit" name="do_save" value="1" class="btn">Save</button>
            <a href="dashboard.php" class="btn btn-secondary">Cancel</a>
        </form>
    </div>

<?php else: // ---------- LIST + SEARCH/FILTER ----------
    $search = isset($_GET['q']) ? trim($_GET['q']) : '';
    $dept   = isset($_GET['department']) ? trim($_GET['department']) : '';
    $class  = isset($_GET['class']) ? trim($_GET['class']) : '';
    $religion = isset($_GET['religion']) ? trim($_GET['religion']) : '';

    $where = array();
    $types = '';
    $params = array();

    if ($search != '') {
        $where[] = "(name LIKE ? OR d_number LIKE ? OR serial_no LIKE ?)";
        $like = '%' . $search . '%';
        $types .= 'sss'; $params[] = $like; $params[] = $like; $params[] = $like;
    }
    if ($dept != '')     { $where[] = "department = ?"; $types .= 's'; $params[] = $dept; }
    if ($class != '')    { $where[] = "class = ?"; $types .= 's'; $params[] = $class; }
    if ($religion != '') { $where[] = "religion = ?"; $types .= 's'; $params[] = $religion; }

    $whereSql = count($where) > 0 ? ('WHERE ' . implode(' AND ', $where)) : '';
    $sql = "SELECT * FROM students $whereSql ORDER BY name ASC";
    $stmt = mysqli_prepare($conn, $sql);
    if (count($params) > 0) {
        $refs = array();
        $refs[] = &$types;
        for ($i = 0; $i < count($params); $i++) { $refs[] = &$params[$i]; }
        call_user_func_array('mysqli_stmt_bind_param', array_merge(array($stmt), $refs));
    }
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
?>
    <div class="card">
        <div class="links">
            <a href="dashboard.php?action=add">+ Add Student</a>
            <a href="transfer.php">Bulk Import / Export</a>
            <a href="staff.php">Staff Search View</a>
        </div>
    </div>

    <div class="card">
        <h2>Students</h2>
        <form method="get" action="dashboard.php">
            <div class="filter">
                <div><label>Search</label><input type="text" name="q" value="<?php echo htmlspecialchars($search); ?>" placeholder="Name / D-Number / Serial No."></div>
                <div><label>Department</label><?php render_select('department', $DEPARTMENTS, $dept, false); ?></div>
                <div><label>Class</label><input type="text" name="class" value="<?php echo htmlspecialchars($class); ?>"></div>
                <div><label>Religion</label><?php render_select('religion', $RELIGIONS, $religion, false); ?></div>
                <div><button type="submit" class="btn btn-small">Filter</button> <a href="dashboard.php" class="btn btn-small btn-secondary">Reset</a></div>
            </div>
        </form>

        <table>
            <tr><th>S.No</th><th>D-Number</th><th>Name</th><th>Department</th><th>Class</th><th>Section</th><th>Residency</th><th>Religion</th><th>Actions</th></tr>
            <?php if (!$result || mysqli_num_rows($result) == 0): ?>
                <tr><td colspan="9" style="text-align:center;">No student records found.</td></tr>
            <?php else: while ($row = mysqli_fetch_assoc($result)): ?>
                <tr>
                    <td><?php echo htmlspecialchars($row['serial_no']); ?></td>
                    <td><?php echo htmlspecialchars($row['d_number']); ?></td>
                    <td><?php echo htmlspecialchars($row['name']); ?></td>
                    <td><?php echo htmlspecialchars($row['department']); ?></td>
                    <td><?php echo htmlspecialchars($row['class']); ?></td>
                    <td><?php echo htmlspecialchars($row['section']); ?></td>
                    <td><?php echo htmlspecialchars($row['residency']); ?></td>
                    <td><?php echo htmlspecialchars($row['religion']); ?></td>
                    <td>
                        <a href="dashboard.php?action=edit&id=<?php echo $row['id']; ?>">Edit</a> |
                        <a href="dashboard.php?action=delete&id=<?php echo $row['id']; ?>">Delete</a>
                    </td>
                </tr>
            <?php endwhile; endif; ?>
        </table>
    </div>
<?php endif; ?>

</div>
</body></html>
