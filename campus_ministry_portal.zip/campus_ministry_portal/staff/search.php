<?php
require_once('../config/db.php');
require_once('../includes/auth.php');
require_once('../includes/options.php');
require_role('staff');

$where = array();

$search = isset($_GET['q']) ? trim($_GET['q']) : '';
$dept   = isset($_GET['department']) ? trim($_GET['department']) : '';
$class  = isset($_GET['class']) ? trim($_GET['class']) : '';

if ($search != '') {
    $s = db_escape($search);
    $where[] = "(name LIKE '%$s%' OR d_number LIKE '%$s%' OR serial_no LIKE '%$s%')";
}
if ($dept != '')  { $where[] = "department = '" . db_escape($dept) . "'"; }
if ($class != '') { $where[] = "class = '" . db_escape($class) . "'"; }

$whereSql = count($where) > 0 ? ('WHERE ' . implode(' AND ', $where)) : 'WHERE 1=1';

// Only search once a query has actually been submitted, to avoid
// dumping the entire roster by default on a read-only console.
$hasSearched = ($search != '' || $dept != '' || $class != '');

$results = array();
if ($hasSearched) {
    $sql = "SELECT * FROM students $whereSql ORDER BY name ASC LIMIT 500";
    $result = mysql_query($sql);
    if ($result) {
        while ($row = mysql_fetch_assoc($result)) {
            $results[] = $row;
        }
    }
}

$departments = get_distinct_values('department');
$classes     = get_distinct_values('class');

$PAGE_TITLE = 'Student Search - Campus Ministry Portal';
$ASSET_PATH = '../';
include('../includes/header.php');
?>

<div class="card">
    <h2>Student Search &amp; View (Read-Only)</h2>
    <p style="font-size:13px;color:#888;">You have view-only access. Contact an administrator to add or edit records.</p>

    <form method="get" action="search.php">
        <div class="filter-bar">
            <div>
                <label>Search (name / D-number / serial no.)</label>
                <input type="text" name="q" value="<?php echo htmlspecialchars($search); ?>">
            </div>
            <div>
                <label>Department</label>
                <select name="department">
                    <option value="">All</option>
                    <?php foreach ($departments as $d): ?>
                        <option value="<?php echo htmlspecialchars($d); ?>" <?php echo ($d == $dept) ? 'selected' : ''; ?>><?php echo htmlspecialchars($d); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div>
                <label>Class</label>
                <select name="class">
                    <option value="">All</option>
                    <?php foreach ($classes as $c): ?>
                        <option value="<?php echo htmlspecialchars($c); ?>" <?php echo ($c == $class) ? 'selected' : ''; ?>><?php echo htmlspecialchars($c); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div>
                <button type="submit" class="btn btn-small">Search</button>
                <a href="search.php" class="btn btn-small btn-secondary">Reset</a>
            </div>
        </div>
    </form>

    <?php if ($hasSearched): ?>
        <table>
            <tr>
                <th>S.No</th><th>D-Number</th><th>Name</th><th>Department</th>
                <th>Class</th><th>Section</th><th>Residency</th><th>Religion</th>
            </tr>
            <?php if (count($results) == 0): ?>
                <tr><td colspan="8" style="text-align:center;">No matching student records found.</td></tr>
            <?php else: ?>
                <?php foreach ($results as $row): ?>
                <tr>
                    <td><?php echo htmlspecialchars($row['serial_no']); ?></td>
                    <td><?php echo htmlspecialchars($row['d_number']); ?></td>
                    <td><?php echo htmlspecialchars($row['name']); ?></td>
                    <td><?php echo htmlspecialchars($row['department']); ?></td>
                    <td><?php echo htmlspecialchars($row['class']); ?></td>
                    <td><?php echo htmlspecialchars($row['section']); ?></td>
                    <td><?php echo htmlspecialchars($row['residency']); ?></td>
                    <td><?php echo htmlspecialchars($row['religion']); ?></td>
                </tr>
                <?php endforeach; ?>
            <?php endif; ?>
        </table>
    <?php else: ?>
        <p style="margin-top:16px;color:#888;">Enter a search term or choose a department/class to view records.</p>
    <?php endif; ?>
</div>

<?php include('../includes/footer.php'); ?>
