<?php
require_once('../config/db.php');
require_once('../includes/auth.php');
require_once('../includes/options.php');
require_role('admin');

// ---- Build filter conditions ----
$where = array();

$search   = isset($_GET['q']) ? trim($_GET['q']) : '';
$dept     = isset($_GET['department']) ? trim($_GET['department']) : '';
$class    = isset($_GET['class']) ? trim($_GET['class']) : '';
$religion = isset($_GET['religion']) ? trim($_GET['religion']) : '';
$residency= isset($_GET['residency']) ? trim($_GET['residency']) : '';

if ($search != '') {
    $s = db_escape($search);
    $where[] = "(name LIKE '%$s%' OR d_number LIKE '%$s%' OR serial_no LIKE '%$s%')";
}
if ($dept != '')     { $where[] = "department = '" . db_escape($dept) . "'"; }
if ($class != '')    { $where[] = "class = '" . db_escape($class) . "'"; }
if ($religion != '') { $where[] = "religion = '" . db_escape($religion) . "'"; }
if ($residency != '') { $where[] = "residency = '" . db_escape($residency) . "'"; }

$whereSql = count($where) > 0 ? ('WHERE ' . implode(' AND ', $where)) : '';

$sql = "SELECT * FROM students $whereSql ORDER BY name ASC";
$result = mysql_query($sql);
if (!$result) {
    die('Query failed: ' . mysql_error());
}

$departments = get_distinct_values('department');
$classes     = get_distinct_values('class');
$religions   = get_distinct_values('religion');

$deleted = isset($_GET['deleted']) ? true : false;

$PAGE_TITLE = 'Manage Students - Campus Ministry Portal';
$ASSET_PATH = '../';
include('../includes/header.php');
?>

<div class="card">
    <h2>Manage Students</h2>

    <?php if ($deleted): ?>
        <div class="alert alert-success">Student record deleted successfully.</div>
    <?php endif; ?>

    <form method="get" action="students_list.php">
        <div class="filter-bar">
            <div>
                <label>Search (name / D-number / serial no.)</label>
                <input type="text" name="q" value="<?php echo htmlspecialchars($search); ?>">
            </div>
            <div>
                <label>Department</label>
                <select name="department">
                    <option value="">All</option>
                    <?php foreach ($departments as $d): ?>
                        <option value="<?php echo htmlspecialchars($d); ?>" <?php echo ($d == $dept) ? 'selected' : ''; ?>><?php echo htmlspecialchars($d); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div>
                <label>Class</label>
                <select name="class">
                    <option value="">All</option>
                    <?php foreach ($classes as $c): ?>
                        <option value="<?php echo htmlspecialchars($c); ?>" <?php echo ($c == $class) ? 'selected' : ''; ?>><?php echo htmlspecialchars($c); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div>
                <label>Religion</label>
                <select name="religion">
                    <option value="">All</option>
                    <?php foreach ($religions as $r): ?>
                        <option value="<?php echo htmlspecialchars($r); ?>" <?php echo ($r == $religion) ? 'selected' : ''; ?>><?php echo htmlspecialchars($r); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div>
                <label>Residency</label>
                <select name="residency">
                    <option value="">All</option>
                    <option value="Day Scholar" <?php echo ($residency == 'Day Scholar') ? 'selected' : ''; ?>>Day Scholar</option>
                    <option value="Hosteller" <?php echo ($residency == 'Hosteller') ? 'selected' : ''; ?>>Hosteller</option>
                </select>
            </div>
            <div>
                <button type="submit" class="btn btn-small">Filter</button>
                <a href="students_list.php" class="btn btn-small btn-secondary">Reset</a>
            </div>
        </div>
    </form>

    <p><a href="student_add.php" class="btn btn-small">+ Add New Student</a></p>

    <table>
        <tr>
            <th>S.No</th>
            <th>D-Number</th>
            <th>Name</th>
            <th>Department</th>
            <th>Class</th>
            <th>Section</th>
            <th>Residency</th>
            <th>Religion</th>
            <th>Actions</th>
        </tr>
        <?php if (mysql_num_rows($result) == 0): ?>
        <tr><td colspan="9" style="text-align:center;">No student records found.</td></tr>
        <?php else: ?>
        <?php while ($row = mysql_fetch_assoc($result)): ?>
        <tr>
            <td><?php echo htmlspecialchars($row['serial_no']); ?></td>
            <td><?php echo htmlspecialchars($row['d_number']); ?></td>
            <td><?php echo htmlspecialchars($row['name']); ?></td>
            <td><?php echo htmlspecialchars($row['department']); ?></td>
            <td><?php echo htmlspecialchars($row['class']); ?></td>
            <td><?php echo htmlspecialchars($row['section']); ?></td>
            <td><?php echo htmlspecialchars($row['residency']); ?></td>
            <td><?php echo htmlspecialchars($row['religion']); ?></td>
            <td class="action-links">
                <a href="student_edit.php?id=<?php echo (int)$row['id']; ?>">Edit</a>
                <a href="student_delete.php?id=<?php echo (int)$row['id']; ?>"
                   onclick="return confirmDelete('<?php echo htmlspecialchars(addslashes($row['name'])); ?>');">Delete</a>
            </td>
        </tr>
        <?php endwhile; ?>
        <?php endif; ?>
    </table>
</div>

<?php include('../includes/footer.php'); ?>
