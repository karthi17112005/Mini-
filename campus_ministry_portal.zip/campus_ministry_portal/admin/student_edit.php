<?php
require_once('../config/db.php');
require_once('../includes/auth.php');
require_role('admin');

$id = isset($_GET['id']) ? (int)$_GET['id'] : (isset($_POST['id']) ? (int)$_POST['id'] : 0);
if ($id <= 0) {
    header('Location: students_list.php');
    exit;
}

$error = '';

// Fetch existing record
$result = mysql_query("SELECT * FROM students WHERE id = $id LIMIT 1");
if (!$result || mysql_num_rows($result) == 0) {
    header('Location: students_list.php');
    exit;
}
$vals = mysql_fetch_assoc($result);

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $vals['serial_no']  = isset($_POST['serial_no']) ? trim($_POST['serial_no']) : '';
    $vals['d_number']   = isset($_POST['d_number']) ? trim($_POST['d_number']) : '';
    $vals['name']       = isset($_POST['name']) ? trim($_POST['name']) : '';
    $vals['department'] = isset($_POST['department']) ? trim($_POST['department']) : '';
    $vals['class']      = isset($_POST['class']) ? trim($_POST['class']) : '';
    $vals['section']    = isset($_POST['section']) ? trim($_POST['section']) : '';
    $vals['residency']  = isset($_POST['residency']) ? trim($_POST['residency']) : '';
    $vals['religion']   = isset($_POST['religion']) ? trim($_POST['religion']) : '';

    if ($vals['d_number'] == '' || $vals['name'] == '' || $vals['department'] == '' || $vals['class'] == '' || $vals['religion'] == '') {
        $error = 'Please fill in all required fields (D-Number, Name, Department, Class, Religion).';
    } else {
        $dnum_esc = db_escape($vals['d_number']);
        // Ensure D-number isn't used by a *different* student
        $check = mysql_query("SELECT id FROM students WHERE d_number = '$dnum_esc' AND id <> $id LIMIT 1");
        if ($check && mysql_num_rows($check) > 0) {
            $error = 'Another student already uses this D-Number.';
        } else {
            $sql = "UPDATE students SET
                serial_no = '" . db_escape($vals['serial_no']) . "',
                d_number = '" . db_escape($vals['d_number']) . "',
                name = '" . db_escape($vals['name']) . "',
                department = '" . db_escape($vals['department']) . "',
                class = '" . db_escape($vals['class']) . "',
                section = '" . db_escape($vals['section']) . "',
                residency = '" . db_escape($vals['residency']) . "',
                religion = '" . db_escape($vals['religion']) . "',
                updated_at = NOW()
                WHERE id = $id";
            if (mysql_query($sql)) {
                header('Location: students_list.php?updated=1');
                exit;
            } else {
                $error = 'Failed to update record: ' . mysql_error();
            }
        }
    }
}

$PAGE_TITLE = 'Edit Student - Campus Ministry Portal';
$ASSET_PATH = '../';
include('../includes/header.php');
?>

<div class="card" style="max-width:600px;">
    <h2>Edit Student</h2>

    <?php if ($error != ''): ?>
        <div class="alert alert-error"><?php echo htmlspecialchars($error); ?></div>
    <?php endif; ?>

    <form id="editStudentForm" method="post" action="student_edit.php?id=<?php echo $id; ?>" onsubmit="return validateStudentForm('editStudentForm');">
        <input type="hidden" name="id" value="<?php echo $id; ?>">

        <label>Serial No.</label>
        <input type="text" name="serial_no" value="<?php echo htmlspecialchars($vals['serial_no']); ?>">

        <label>D-Number *</label>
        <input type="text" name="d_number" value="<?php echo htmlspecialchars($vals['d_number']); ?>" required>

        <label>Full Name *</label>
        <input type="text" name="name" value="<?php echo htmlspecialchars($vals['name']); ?>" required>

        <label>Department *</label>
        <input type="text" name="department" value="<?php echo htmlspecialchars($vals['department']); ?>" required>

        <label>Class *</label>
        <input type="text" name="class" value="<?php echo htmlspecialchars($vals['class']); ?>" required>

        <label>Section</label>
        <input type="text" name="section" value="<?php echo htmlspecialchars($vals['section']); ?>">

        <label>Residency Status *</label>
        <select name="residency" required>
            <option value="Day Scholar" <?php echo ($vals['residency'] == 'Day Scholar') ? 'selected' : ''; ?>>Day Scholar</option>
            <option value="Hosteller" <?php echo ($vals['residency'] == 'Hosteller') ? 'selected' : ''; ?>>Hosteller</option>
        </select>

        <label>Religious Affiliation *</label>
        <input type="text" name="religion" value="<?php echo htmlspecialchars($vals['religion']); ?>" required>

        <button type="submit" class="btn">Update Student</button>
        <a href="students_list.php" class="btn btn-secondary">Cancel</a>
    </form>
</div>

<?php include('../includes/footer.php'); ?>
