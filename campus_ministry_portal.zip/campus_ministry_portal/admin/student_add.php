<?php
require_once('../config/db.php');
require_once('../includes/auth.php');
require_role('admin');

$error = '';
$success = false;

// Pre-fill values on validation failure
$vals = array(
    'serial_no' => '', 'd_number' => '', 'name' => '', 'department' => '',
    'class' => '', 'section' => '', 'residency' => 'Day Scholar', 'religion' => ''
);

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    foreach ($vals as $key => $default) {
        $vals[$key] = isset($_POST[$key]) ? trim($_POST[$key]) : '';
    }

    if ($vals['d_number'] == '' || $vals['name'] == '' || $vals['department'] == '' || $vals['class'] == '' || $vals['religion'] == '') {
        $error = 'Please fill in all required fields (D-Number, Name, Department, Class, Religion).';
    } else {
        // Check for duplicate D-number
        $dnum_esc = db_escape($vals['d_number']);
        $check = mysql_query("SELECT id FROM students WHERE d_number = '$dnum_esc' LIMIT 1");
        if ($check && mysql_num_rows($check) > 0) {
            $error = 'A student with this D-Number already exists.';
        } else {
            $sql = "INSERT INTO students
                (serial_no, d_number, name, department, class, section, residency, religion, created_at)
                VALUES (
                    '" . db_escape($vals['serial_no']) . "',
                    '" . db_escape($vals['d_number']) . "',
                    '" . db_escape($vals['name']) . "',
                    '" . db_escape($vals['department']) . "',
                    '" . db_escape($vals['class']) . "',
                    '" . db_escape($vals['section']) . "',
                    '" . db_escape($vals['residency']) . "',
                    '" . db_escape($vals['religion']) . "',
                    NOW()
                )";
            if (mysql_query($sql)) {
                header('Location: students_list.php?added=1');
                exit;
            } else {
                $error = 'Failed to save record: ' . mysql_error();
            }
        }
    }
}

$PAGE_TITLE = 'Add Student - Campus Ministry Portal';
$ASSET_PATH = '../';
include('../includes/header.php');
?>

<div class="card" style="max-width:600px;">
    <h2>Add New Student</h2>

    <?php if ($error != ''): ?>
        <div class="alert alert-error"><?php echo htmlspecialchars($error); ?></div>
    <?php endif; ?>

    <form id="addStudentForm" method="post" action="student_add.php" onsubmit="return validateStudentForm('addStudentForm');">
        <label>Serial No.</label>
        <input type="text" name="serial_no" value="<?php echo htmlspecialchars($vals['serial_no']); ?>">

        <label>D-Number *</label>
        <input type="text" name="d_number" value="<?php echo htmlspecialchars($vals['d_number']); ?>" required>

        <label>Full Name *</label>
        <input type="text" name="name" value="<?php echo htmlspecialchars($vals['name']); ?>" required>

        <label>Department *</label>
        <input type="text" name="department" value="<?php echo htmlspecialchars($vals['department']); ?>" required>

        <label>Class *</label>
        <input type="text" name="class" value="<?php echo htmlspecialchars($vals['class']); ?>" required>

        <label>Section</label>
        <input type="text" name="section" value="<?php echo htmlspecialchars($vals['section']); ?>">

        <label>Residency Status *</label>
        <select name="residency" required>
            <option value="Day Scholar" <?php echo ($vals['residency'] == 'Day Scholar') ? 'selected' : ''; ?>>Day Scholar</option>
            <option value="Hosteller" <?php echo ($vals['residency'] == 'Hosteller') ? 'selected' : ''; ?>>Hosteller</option>
        </select>

        <label>Religious Affiliation *</label>
        <input type="text" name="religion" value="<?php echo htmlspecialchars($vals['religion']); ?>" required>

        <button type="submit" class="btn">Save Student</button>
        <a href="students_list.php" class="btn btn-secondary">Cancel</a>
    </form>
</div>

<?php include('../includes/footer.php'); ?>
