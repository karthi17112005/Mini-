<?php
require_once('../config/db.php');
require_once('../includes/auth.php');
require_role('admin');

$dept      = isset($_GET['department']) ? trim($_GET['department']) : '';
$class     = isset($_GET['class']) ? trim($_GET['class']) : '';
$religion  = isset($_GET['religion']) ? trim($_GET['religion']) : '';
$residency = isset($_GET['residency']) ? trim($_GET['residency']) : '';

$where = array();
if ($dept != '')      { $where[] = "department = '" . db_escape($dept) . "'"; }
if ($class != '')     { $where[] = "class = '" . db_escape($class) . "'"; }
if ($religion != '')  { $where[] = "religion = '" . db_escape($religion) . "'"; }
if ($residency != '') { $where[] = "residency = '" . db_escape($residency) . "'"; }
$whereSql = count($where) > 0 ? ('WHERE ' . implode(' AND ', $where)) : '';

$sql = "SELECT serial_no, d_number, name, department, class, section, residency, religion
        FROM students $whereSql ORDER BY department, class, name";
$result = mysql_query($sql);
if (!$result) {
    die('Query failed: ' . mysql_error());
}

$filterDesc = array();
if ($dept != '')      $filterDesc[] = "Department: $dept";
if ($class != '')     $filterDesc[] = "Class: $class";
if ($religion != '')  $filterDesc[] = "Religion: $religion";
if ($residency != '') $filterDesc[] = "Residency: $residency";
$filterLine = count($filterDesc) > 0 ? implode(' | ', $filterDesc) : 'All Students';
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Student Export Report</title>
<link rel="stylesheet" href="../css/style.css">
<style>
    body { padding: 30px; }
    h1 { color: #4a2c8f; }
    .meta { margin-bottom: 20px; font-size: 13px; color: #555; }
</style>
</head>
<body>
    <div class="no-print" style="margin-bottom:16px;">
        <button class="btn" onclick="window.print();">Print / Save as PDF</button>
    </div>

    <h1>Campus Ministry Portal &ndash; Student Report</h1>
    <div class="meta">
        <p>Filter: <strong><?php echo htmlspecialchars($filterLine); ?></strong></p>
        <p>Generated: <?php echo date('d M Y, h:i A'); ?> by <?php echo htmlspecialchars(current_user_name()); ?></p>
        <p>Total records: <strong><?php echo mysql_num_rows($result); ?></strong></p>
    </div>

    <table>
        <tr>
            <th>S.No</th><th>D-Number</th><th>Name</th><th>Department</th>
            <th>Class</th><th>Section</th><th>Residency</th><th>Religion</th>
        </tr>
        <?php while ($row = mysql_fetch_assoc($result)): ?>
        <tr>
            <td><?php echo htmlspecialchars($row['serial_no']); ?></td>
            <td><?php echo htmlspecialchars($row['d_number']); ?></td>
            <td><?php echo htmlspecialchars($row['name']); ?></td>
            <td><?php echo htmlspecialchars($row['department']); ?></td>
            <td><?php echo htmlspecialchars($row['class']); ?></td>
            <td><?php echo htmlspecialchars($row['section']); ?></td>
            <td><?php echo htmlspecialchars($row['residency']); ?></td>
            <td><?php echo htmlspecialchars($row['religion']); ?></td>
        </tr>
        <?php endwhile; ?>
    </table>
</body>
</html>
