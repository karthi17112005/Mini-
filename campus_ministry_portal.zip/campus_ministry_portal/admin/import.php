<?php
require_once('../config/db.php');
require_once('../includes/auth.php');
require_role('admin');

/**
 * Expected CSV columns (header row required), in this order:
 * serial_no, d_number, name, department, class, section, residency, religion
 *
 * Note: For true .xlsx files, open them in Excel and use
 * "Save As -> CSV (Comma delimited)" first, since PHP 5.1.4 has
 * no built-in Excel reader. This keeps the stack dependency-free.
 */

$message = '';
$messageType = '';
$importedCount = 0;
$skippedRows = array();

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_FILES['csv_file'])) {

    if ($_FILES['csv_file']['error'] !== UPLOAD_ERR_OK) {
        $message = 'File upload failed. Please try again.';
        $messageType = 'error';
    } else {
        $tmpPath = $_FILES['csv_file']['tmp_name'];
        $fileName = $_FILES['csv_file']['name'];
        $ext = strtolower(substr($fileName, strrpos($fileName, '.') + 1));

        if ($ext != 'csv') {
            $message = 'Please upload a .csv file (export .xlsx to CSV first).';
            $messageType = 'error';
        } else {
            $handle = fopen($tmpPath, 'r');
            if ($handle === false) {
                $message = 'Could not read the uploaded file.';
                $messageType = 'error';
            } else {
                $rowNum = 0;
                $header = null;

                while (($row = fgetcsv($handle, 2000, ',')) !== false) {
                    $rowNum++;

                    // First row = header, skip it
                    if ($rowNum == 1) {
                        $header = $row;
                        continue;
                    }

                    // Expecting 8 columns
                    if (count($row) < 8) {
                        $skippedRows[] = "Row $rowNum: not enough columns";
                        continue;
                    }

                    list($serial_no, $d_number, $name, $department, $class, $section, $residency, $religion) = array_map('trim', $row);

                    if ($d_number == '' || $name == '' || $department == '' || $class == '' || $religion == '') {
                        $skippedRows[] = "Row $rowNum: missing required field(s)";
                        continue;
                    }

                    if ($residency != 'Day Scholar' && $residency != 'Hosteller') {
                        $residency = 'Day Scholar'; // default fallback
                    }

                    $dnum_esc = db_escape($d_number);
                    $existing = mysql_query("SELECT id FROM students WHERE d_number = '$dnum_esc' LIMIT 1");

                    if ($existing && mysql_num_rows($existing) > 0) {
                        $skippedRows[] = "Row $rowNum: D-Number '$d_number' already exists (skipped)";
                        continue;
                    }

                    $sql = "INSERT INTO students
                        (serial_no, d_number, name, department, class, section, residency, religion, created_at)
                        VALUES (
                            '" . db_escape($serial_no) . "',
                            '" . db_escape($d_number) . "',
                            '" . db_escape($name) . "',
                            '" . db_escape($department) . "',
                            '" . db_escape($class) . "',
                            '" . db_escape($section) . "',
                            '" . db_escape($residency) . "',
                            '" . db_escape($religion) . "',
                            NOW()
                        )";

                    if (mysql_query($sql)) {
                        $importedCount++;
                    } else {
                        $skippedRows[] = "Row $rowNum: database error - " . mysql_error();
                    }
                }
                fclose($handle);

                $message = "$importedCount student record(s) imported successfully.";
                $messageType = 'success';
            }
        }
    }
}

$PAGE_TITLE = 'Bulk Import - Campus Ministry Portal';
$ASSET_PATH = '../';
include('../includes/header.php');
?>

<div class="card" style="max-width:700px;">
    <h2>Bulk Import Students (CSV)</h2>

    <?php if ($message != ''): ?>
        <div class="alert alert-<?php echo $messageType; ?>"><?php echo htmlspecialchars($message); ?></div>
    <?php endif; ?>

    <?php if (count($skippedRows) > 0): ?>
        <div class="alert alert-error">
            <strong><?php echo count($skippedRows); ?> row(s) skipped:</strong>
            <ul style="margin:8px 0 0 18px;">
                <?php foreach ($skippedRows as $s): ?>
                    <li><?php echo htmlspecialchars($s); ?></li>
                <?php endforeach; ?>
            </ul>
        </div>
    <?php endif; ?>

    <p>Upload a CSV file with the following column order (a header row is expected and skipped automatically):</p>
    <p><code>serial_no, d_number, name, department, class, section, residency, religion</code></p>
    <p style="font-size:12px;color:#888;">Residency must be exactly "Day Scholar" or "Hosteller". If you have an .xlsx file, open it in Excel/Calc and choose "Save As &rarr; CSV" first.</p>

    <form method="post" action="import.php" enctype="multipart/form-data">
        <label>CSV File *</label>
        <input type="file" name="csv_file" accept=".csv" required>
        <button type="submit" class="btn">Upload &amp; Import</button>
        <a href="dashboard.php" class="btn btn-secondary">Back to Dashboard</a>
    </form>
</div>

<?php include('../includes/footer.php'); ?>
