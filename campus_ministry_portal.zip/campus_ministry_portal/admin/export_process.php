<?php
require_once('../config/db.php');
require_once('../includes/auth.php');
require_role('admin');

$dept      = isset($_GET['department']) ? trim($_GET['department']) : '';
$class     = isset($_GET['class']) ? trim($_GET['class']) : '';
$religion  = isset($_GET['religion']) ? trim($_GET['religion']) : '';
$residency = isset($_GET['residency']) ? trim($_GET['residency']) : '';

$where = array();
if ($dept != '')      { $where[] = "department = '" . db_escape($dept) . "'"; }
if ($class != '')     { $where[] = "class = '" . db_escape($class) . "'"; }
if ($religion != '')  { $where[] = "religion = '" . db_escape($religion) . "'"; }
if ($residency != '') { $where[] = "residency = '" . db_escape($residency) . "'"; }
$whereSql = count($where) > 0 ? ('WHERE ' . implode(' AND ', $where)) : '';

$sql = "SELECT serial_no, d_number, name, department, class, section, residency, religion
        FROM students $whereSql ORDER BY department, class, name";
$result = mysql_query($sql);
if (!$result) {
    die('Query failed: ' . mysql_error());
}

$filename = 'student_export_' . date('Ymd_His') . '.csv';

header('Content-Type: text/csv; charset=UTF-8');
header('Content-Disposition: attachment; filename="' . $filename . '"');
header('Pragma: no-cache');
header('Expires: 0');

$out = fopen('php://output', 'w');

// Header row (Excel opens this natively)
fputcsv($out, array('Serial No', 'D-Number', 'Name', 'Department', 'Class', 'Section', 'Residency', 'Religion'));

while ($row = mysql_fetch_assoc($result)) {
    fputcsv($out, array(
        $row['serial_no'], $row['d_number'], $row['name'], $row['department'],
        $row['class'], $row['section'], $row['residency'], $row['religion']
    ));
}

fclose($out);
exit;
?>
