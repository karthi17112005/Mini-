<?php
require_once('../config/db.php');
require_once('../includes/auth.php');
require_once('../includes/options.php');
require_role('admin');

$departments = get_distinct_values('department');
$classes     = get_distinct_values('class');
$religions   = get_distinct_values('religion');

$dept     = isset($_GET['department']) ? trim($_GET['department']) : '';
$class    = isset($_GET['class']) ? trim($_GET['class']) : '';
$religion = isset($_GET['religion']) ? trim($_GET['religion']) : '';
$residency= isset($_GET['residency']) ? trim($_GET['residency']) : '';

// Build a live preview count/query for whatever is currently selected
$where = array();
if ($dept != '')      { $where[] = "department = '" . db_escape($dept) . "'"; }
if ($class != '')     { $where[] = "class = '" . db_escape($class) . "'"; }
if ($religion != '')  { $where[] = "religion = '" . db_escape($religion) . "'"; }
if ($residency != '') { $where[] = "residency = '" . db_escape($residency) . "'"; }
$whereSql = count($where) > 0 ? ('WHERE ' . implode(' AND ', $where)) : '';

$previewResult = mysql_query("SELECT COUNT(*) AS cnt FROM students $whereSql");
$previewRow = mysql_fetch_assoc($previewResult);
$previewCount = $previewRow['cnt'];

$PAGE_TITLE = 'Export Students - Campus Ministry Portal';
$ASSET_PATH = '../';
include('../includes/header.php');
?>

<div class="card" style="max-width:700px;">
    <h2>Multi-Filter &amp; Export</h2>
    <p>Select criteria to export a targeted list (e.g. Catholic students in BSc CS, Section A) to Excel or a printable document.</p>

    <form method="get" action="export.php" id="exportFilterForm">
        <label>Department</label>
        <select name="department">
            <option value="">All Departments</option>
            <?php foreach ($departments as $d): ?>
                <option value="<?php echo htmlspecialchars($d); ?>" <?php echo ($d == $dept) ? 'selected' : ''; ?>><?php echo htmlspecialchars($d); ?></option>
            <?php endforeach; ?>
        </select>

        <label>Class</label>
        <select name="class">
            <option value="">All Classes</option>
            <?php foreach ($classes as $c): ?>
                <option value="<?php echo htmlspecialchars($c); ?>" <?php echo ($c == $class) ? 'selected' : ''; ?>><?php echo htmlspecialchars($c); ?></option>
            <?php endforeach; ?>
        </select>

        <label>Religious Affiliation</label>
        <select name="religion">
            <option value="">All Religions</option>
            <?php foreach ($religions as $r): ?>
                <option value="<?php echo htmlspecialchars($r); ?>" <?php echo ($r == $religion) ? 'selected' : ''; ?>><?php echo htmlspecialchars($r); ?></option>
            <?php endforeach; ?>
        </select>

        <label>Residency</label>
        <select name="residency">
            <option value="">All</option>
            <option value="Day Scholar" <?php echo ($residency == 'Day Scholar') ? 'selected' : ''; ?>>Day Scholar</option>
            <option value="Hosteller" <?php echo ($residency == 'Hosteller') ? 'selected' : ''; ?>>Hosteller</option>
        </select>

        <button type="submit" class="btn">Update Preview</button>
    </form>

    <p style="margin-top:16px;"><strong><?php echo (int)$previewCount; ?></strong> student(s) match the current filter.</p>

    <div style="margin-top:16px;">
        <a class="btn" href="export_process.php?department=<?php echo urlencode($dept); ?>&class=<?php echo urlencode($class); ?>&religion=<?php echo urlencode($religion); ?>&residency=<?php echo urlencode($residency); ?>&format=csv">Export to Excel (CSV)</a>
        <a class="btn btn-secondary" href="export_print.php?department=<?php echo urlencode($dept); ?>&class=<?php echo urlencode($class); ?>&religion=<?php echo urlencode($religion); ?>&residency=<?php echo urlencode($residency); ?>" target="_blank">Printable Document</a>
        <a href="dashboard.php" class="btn btn-secondary">Back to Dashboard</a>
    </div>
</div>

<?php include('../includes/footer.php'); ?>
