<?php
require_once('../config/db.php');
require_once('../includes/auth.php');
require_role('admin');

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if ($id > 0) {
    mysql_query("DELETE FROM students WHERE id = $id");
}

header('Location: students_list.php?deleted=1');
exit;
?>
