<?php
require_once('../config/db.php');
require_once('../includes/auth.php');
require_role('admin');

$countResult = mysql_query("SELECT COUNT(*) AS cnt FROM students");
$countRow = mysql_fetch_assoc($countResult);
$totalStudents = $countRow['cnt'];

$PAGE_TITLE = 'Admin Dashboard - Campus Ministry Portal';
$ASSET_PATH = '../';
include('../includes/header.php');
?>

<div class="card">
    <h2>Welcome, <?php echo htmlspecialchars(current_user_name()); ?></h2>
    <p>Total student records: <strong><?php echo (int)$totalStudents; ?></strong></p>
</div>

<div class="dashboard-links">
    <a href="students_list.php">📋<br>Manage Students</a>
    <a href="student_add.php">➕<br>Add New Student</a>
    <a href="import.php">📥<br>Bulk Import (CSV/Excel)</a>
    <a href="export.php">📤<br>Filter &amp; Export</a>
</div>

<?php include('../includes/footer.php'); ?>
