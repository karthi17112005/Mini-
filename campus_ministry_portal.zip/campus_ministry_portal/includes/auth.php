<?php
/**
 * Session + role-based access control helpers.
 * Include this AFTER config/db.php on every protected page.
 */

if (session_id() == '') {
    session_start();
}

function is_logged_in() {
    return isset($_SESSION['user_id']) && isset($_SESSION['role']);
}

function current_role() {
    return isset($_SESSION['role']) ? $_SESSION['role'] : null;
}

function current_user_name() {
    return isset($_SESSION['full_name']) ? $_SESSION['full_name'] : '';
}

/**
 * Force login. Call at the top of every protected page.
 */
function require_login() {
    if (!is_logged_in()) {
        header('Location: ../index.php?err=session');
        exit;
    }
}

/**
 * Restrict a page to a specific role ('admin' or 'staff').
 */
function require_role($role) {
    require_login();
    if (current_role() != $role) {
        header('Location: ../index.php?err=denied');
        exit;
    }
}
?>
