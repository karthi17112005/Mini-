<?php
/**
 * Returns a sorted array of distinct values for a given students column.
 * Used to populate filter dropdowns dynamically from real data.
 * $column must be one of a whitelist to prevent SQL injection.
 */
function get_distinct_values($column) {
    $allowed = array('department', 'class', 'section', 'religion', 'residency');
    if (!in_array($column, $allowed)) {
        return array();
    }
    $values = array();
    $sql = "SELECT DISTINCT $column FROM students WHERE $column <> '' ORDER BY $column ASC";
    $result = mysql_query($sql);
    if ($result) {
        while ($row = mysql_fetch_assoc($result)) {
            $values[] = $row[$column];
        }
    }
    return $values;
}
?>
