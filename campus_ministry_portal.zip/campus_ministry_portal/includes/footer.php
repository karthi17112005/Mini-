</main>
<footer class="footer">
    <p>&copy; <?php echo date('Y'); ?> Campus Ministry Portal &mdash; Mini Project</p>
</footer>
<script src="<?php echo isset($ASSET_PATH) ? $ASSET_PATH : ''; ?>js/script.js"></script>
</body>
</html>
