<?php if (!isset($PAGE_TITLE)) { $PAGE_TITLE = 'Campus Ministry Portal'; } ?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title><?php echo htmlspecialchars($PAGE_TITLE); ?></title>
<link rel="stylesheet" href="<?php echo isset($ASSET_PATH) ? $ASSET_PATH : ''; ?>css/style.css">
</head>
<body>
<header class="topbar">
    <div class="brand">⛪ Campus Ministry Portal</div>
    <?php if (isset($_SESSION['user_id'])): ?>
    <div class="user-info">
        <span>Logged in as <strong><?php echo htmlspecialchars($_SESSION['full_name']); ?></strong>
        (<?php echo htmlspecialchars(ucfirst($_SESSION['role'])); ?>)</span>
        <a class="logout-link" href="<?php echo isset($ASSET_PATH) ? $ASSET_PATH : ''; ?>logout.php">Logout</a>
    </div>
    <?php endif; ?>
</header>
<main class="container">
