<?php
require_once('config/db.php');
require_once('includes/auth.php');

if ($_SERVER['REQUEST_METHOD'] != 'POST') {
    header('Location: index.php');
    exit;
}

$username = isset($_POST['username']) ? trim($_POST['username']) : '';
$password = isset($_POST['password']) ? $_POST['password'] : '';

if ($username == '' || $password == '') {
    header('Location: index.php?err=invalid');
    exit;
}

$username_esc = db_escape($username);
$password_hash = md5($password);

$sql = "SELECT id, username, full_name, role FROM users
        WHERE username = '$username_esc' AND password = '$password_hash' LIMIT 1";
$result = mysql_query($sql);

if ($result && mysql_num_rows($result) == 1) {
    $user = mysql_fetch_assoc($result);

    $_SESSION['user_id']   = $user['id'];
    $_SESSION['username']  = $user['username'];
    $_SESSION['full_name'] = $user['full_name'];
    $_SESSION['role']      = $user['role'];

    if ($user['role'] == 'admin') {
        header('Location: admin/dashboard.php');
    } else {
        header('Location: staff/search.php');
    }
    exit;
} else {
    header('Location: index.php?err=invalid');
    exit;
}
?>
