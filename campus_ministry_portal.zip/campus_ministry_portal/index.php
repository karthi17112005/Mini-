<?php
require_once('config/db.php');
require_once('includes/auth.php');

// If already logged in, send to the right dashboard
if (is_logged_in()) {
    if (current_role() == 'admin') {
        header('Location: admin/dashboard.php');
    } else {
        header('Location: staff/search.php');
    }
    exit;
}

$error = '';
if (isset($_GET['err'])) {
    if ($_GET['err'] == 'invalid') { $error = 'Invalid username or password.'; }
    elseif ($_GET['err'] == 'session') { $error = 'Please log in to continue.'; }
    elseif ($_GET['err'] == 'denied') { $error = 'You do not have access to that page.'; }
}

$PAGE_TITLE = 'Login - Campus Ministry Portal';
$ASSET_PATH = '';
include('includes/header.php');
?>

<div class="login-box">
    <h2>Sign In</h2>
    <?php if ($error != ''): ?>
        <div class="alert alert-error"><?php echo htmlspecialchars($error); ?></div>
    <?php endif; ?>
    <form action="login_process.php" method="post">
        <label for="username">Username</label>
        <input type="text" id="username" name="username" required autofocus>

        <label for="password">Password</label>
        <input type="password" id="password" name="password" required>

        <button type="submit" class="btn" style="width:100%;">Login</button>
    </form>
    <p style="margin-top:16px; font-size:12px; color:#888; text-align:center;">
        Demo accounts &mdash; Admin: admin / admin123 &nbsp;|&nbsp; Staff: staff / staff123
    </p>
</div>

<?php include('includes/footer.php'); ?>
