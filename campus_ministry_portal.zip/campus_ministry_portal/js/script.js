// Campus Ministry Portal - client-side helpers

function confirmDelete(name) {
    return confirm('Are you sure you want to delete the record for "' + name + '"? This cannot be undone.');
}

// Simple client-side required-field check before submit (server also validates)
function validateStudentForm(formId) {
    var form = document.getElementById(formId);
    if (!form) return true;
    var required = form.querySelectorAll('[required]');
    for (var i = 0; i < required.length; i++) {
        if (!required[i].value || required[i].value.trim() === '') {
            alert('Please fill in all required fields.');
            required[i].focus();
            return false;
        }
    }
    return true;
}

// Toggle "select all" checkboxes in the student list table
function toggleAll(source) {
    var checkboxes = document.getElementsByName('student_ids[]');
    for (var i = 0; i < checkboxes.length; i++) {
        checkboxes[i].checked = source.checked;
    }
}
