-- Campus Ministry Portal
-- MySQL 5.0.21 compatible schema
-- Import this file first via phpMyAdmin or `mysql -u root -p < schema.sql`

CREATE DATABASE IF NOT EXISTS campus_ministry_portal;
USE campus_ministry_portal;

-- ------------------------------------------------------------
-- Table: users  (Administrators and Staff)
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS users (
  id INT NOT NULL AUTO_INCREMENT,
  username VARCHAR(50) NOT NULL,
  password VARCHAR(64) NOT NULL,   -- md5 hash (PHP 5.1.4 has no password_hash)
  full_name VARCHAR(100) NOT NULL,
  role ENUM('admin','staff') NOT NULL DEFAULT 'staff',
  department VARCHAR(100) DEFAULT NULL, -- staff can be restricted to a dept (optional)
  created_at DATETIME NOT NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uniq_username (username)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- ------------------------------------------------------------
-- Table: students
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS students (
  id INT NOT NULL AUTO_INCREMENT,
  serial_no VARCHAR(20) DEFAULT NULL,
  d_number VARCHAR(30) NOT NULL,
  name VARCHAR(150) NOT NULL,
  department VARCHAR(100) NOT NULL,
  class VARCHAR(50) NOT NULL,
  section VARCHAR(20) DEFAULT NULL,
  residency ENUM('Day Scholar','Hosteller') NOT NULL DEFAULT 'Day Scholar',
  religion VARCHAR(50) NOT NULL,
  created_at DATETIME NOT NULL,
  updated_at DATETIME DEFAULT NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uniq_dnumber (d_number),
  KEY idx_department (department),
  KEY idx_class (class),
  KEY idx_religion (religion),
  KEY idx_residency (residency)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- ------------------------------------------------------------
-- Seed data: default admin (username: admin / password: admin123)
-- and one staff account (username: staff / password: staff123)
-- md5('admin123') = 0192023a7bbd73250516f069df18b500
-- md5('staff123') = 6f4dd8a90b3a5f8e0f39d8b6c4b3a1c1  (placeholder, recompute below)
-- ------------------------------------------------------------
INSERT INTO users (username, password, full_name, role, department, created_at)
VALUES
('admin', MD5('admin123'), 'System Administrator', 'admin', NULL, NOW()),
('staff', MD5('staff123'), 'Ministry Staff', 'staff', 'Computer Science', NOW());

-- Sample students (optional demo data)
INSERT INTO students (serial_no, d_number, name, department, class, section, residency, religion, created_at) VALUES
('1', 'D2024001', 'John Mathew', 'Computer Science', 'BSc CS', 'A', 'Hosteller', 'Catholic', NOW()),
('2', 'D2024002', 'Aisha Khan', 'Commerce', 'BCom', 'B', 'Day Scholar', 'Muslim', NOW()),
('3', 'D2024003', 'Ravi Kumar', 'Physics', 'BSc Physics', 'A', 'Day Scholar', 'Hindu', NOW()),
('4', 'D2024004', 'Grace Thomas', 'Computer Science', 'BSc CS', 'A', 'Hosteller', 'Catholic', NOW());
