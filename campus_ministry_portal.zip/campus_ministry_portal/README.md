# Campus Ministry Portal

A centralized web-based demographic management and student outreach platform.
Built to match the stack in the project abstract: **HTML / CSS / Vanilla JS**
frontend, **PHP** backend, **MySQL** database, targeting **PHP 5.1.4** and
**MySQL 5.0.21 Community (NT)** on **WampServer**.

## ⚠️ Important compatibility notes

PHP 5.1.4 and MySQL 5.0.21 are extremely old (circa 2005–2006) and are no
longer maintained or security-patched. This code was deliberately written to
match that target for a mini-project/college submission:

- Uses the classic `mysql_*` extension (not `mysqli` or `PDO`), since that's
  what a WampServer stack from that era ships with.
- Uses `md5()` for password hashing instead of `password_hash()`, because
  `password_hash()` was only added in PHP 5.5.
- Avoids any PHP 5.3+ syntax (no namespaces, no short array `[]` syntax,
  no anonymous functions/closures, no `??` operator, etc.).
- CSV import/export is used for the "Excel" features, since reading/writing
  real `.xlsx` binary files needs a library (PHPExcel/PhpSpreadsheet) that
  won't run on PHP 5.1.4. CSV opens natively in Excel, so bulk import
  expects a `.csv` (Save As → CSV from Excel) and export downloads a `.csv`
  that Excel opens directly.

If you actually have flexibility on versions, modern PHP (8.x) with
`mysqli`/`PDO` and a maintained MySQL/MariaDB is strongly recommended for
any real deployment — the versions above have known unpatched
vulnerabilities. This project runs fine on modern PHP with only the
`mysql_*` calls needing a mysqli swap (see below).

## Setup (WampServer, PHP 5.1.4 / MySQL 5.0.21)

1. Copy the `campus_ministry_portal` folder into your WampServer `www`
   directory, e.g. `C:\wamp\www\campus_ministry_portal`.
2. Start WampServer (Apache + MySQL).
3. Open **phpMyAdmin** (or the MySQL command line) and import
   `sql/schema.sql`. This creates the `campus_ministry_portal` database,
   the `users` and `students` tables, a default admin/staff account, and a
   few sample student rows.
4. Check `config/db.php` — defaults are `host=localhost`, `user=root`,
   `password=` (blank), `database=campus_ministry_portal`, which matches a
   stock WampServer install. Edit if your setup differs.
5. Visit `http://localhost/campus_ministry_portal/` in your browser.

### Default logins (change these after first login)

| Role  | Username | Password |
|-------|----------|----------|
| Admin | admin    | admin123 |
| Staff | staff    | staff123 |

## Folder structure

```
campus_ministry_portal/
├── index.php              Login page
├── login_process.php      Login handler
├── logout.php
├── config/db.php           DB connection
├── includes/               Shared header/footer/auth/options helpers
├── css/style.css
├── js/script.js
├── admin/
│   ├── dashboard.php
│   ├── students_list.php   Search/filter + list + edit/delete links
│   ├── student_add.php     Create
│   ├── student_edit.php    Update
│   ├── student_delete.php  Delete
│   ├── import.php          Bulk CSV import
│   ├── export.php          Multi-filter export screen
│   ├── export_process.php  Streams the CSV/Excel file
│   └── export_print.php    Printable HTML report
├── staff/
│   └── search.php           Read-only search/view console
└── sql/schema.sql
```

## Modules (matches the project abstract)

- **User Authentication & Role Management** — session-based login,
  `admin` vs `staff` roles, enforced via `includes/auth.php`.
- **Student Data Management (CRUD)** — `admin/student_add.php`,
  `student_edit.php`, `student_delete.php`, listed in `students_list.php`.
- **Bulk CSV/Excel Data Import** — `admin/import.php`, expects columns
  `serial_no, d_number, name, department, class, section, residency, religion`.
- **Staff Search & View Console** — `staff/search.php`, read-only.
- **Multi-Filter & Export Module** — `admin/export.php` (filter by
  department/class/religion/residency) → CSV export or a printable report.

## Bulk import CSV format

First row is a header (skipped automatically). Example:

```csv
serial_no,d_number,name,department,class,section,residency,religion
5,D2024005,Maria Fernandez,Computer Science,BSc CS,A,Hosteller,Catholic
6,D2024006,Ahmed Ali,Commerce,BCom,B,Day Scholar,Muslim
```

## Porting to a modern PHP version (recommended)

If your environment actually runs PHP 7+/8.x, swap the `mysql_*` calls in
`config/db.php` (and the `db_escape()` helper) for `mysqli_*` equivalents —
the rest of the code (queries, logic, HTML) needs no changes since plain
SQL strings are unaffected. `password_hash()`/`password_verify()` can also
replace `md5()` for real deployments.
