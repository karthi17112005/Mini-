<?php
/**
 * Database connection
 * Compatible with PHP 5.1.4 + MySQL 5.0.21 (WampServer)
 * Uses the classic mysql_* extension (available in PHP 5.1.4;
 * it was only deprecated in PHP 5.5+ and removed in PHP 7).
 */

$DB_HOST = 'localhost';
$DB_USER = 'root';
$DB_PASS = '';
$DB_NAME = 'campus_ministry_portal';

$conn = mysql_connect($DB_HOST, $DB_USER, $DB_PASS);
if (!$conn) {
    die('Database connection failed: ' . mysql_error());
}

$db_selected = mysql_select_db($DB_NAME, $conn);
if (!$db_selected) {
    die('Could not select database: ' . mysql_error());
}

// Helper: safe string escaping for queries
function db_escape($value) {
    global $conn;
    return mysql_real_escape_string($value, $conn);
}
?>
