<?php
require_once('includes/auth.php');
$_SESSION = array();
if (session_id() != '') {
    session_destroy();
}
header('Location: index.php');
exit;
?>
